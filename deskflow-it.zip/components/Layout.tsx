
import React, { useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Ticket, MessageSquare, LogOut, Menu, X, User as UserIcon, ShieldCheck, BookOpen, Monitor, Activity } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { useNotification } from '../context/NotificationContext';
import { Role } from '../types';
import Toast from './Toast';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { user, logout } = useAuth();
  const { messages, users } = useData();
  const { showNotification, notifications, removeNotification } = useNotification();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  // Notification Listener Logic
  const prevMessagesLength = useRef(messages.length);
  
  // Audio ref for notification sound
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Calculate total unread messages for the sidebar badge
  const totalUnreadCount = user 
    ? messages.filter(m => m.receiverId === user.id && !m.read).length 
    : 0;

  // 1. Initialize Audio and Request Browser Notification Permission
  useEffect(() => {
    // Simple "Pop" sound for notifications
    audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2346/2346-preview.mp3');
    audioRef.current.volume = 0.5;

    if ('Notification' in window && Notification.permission !== 'granted') {
      // Note: Browsers may block this unless triggered by user interaction. 
      // Ideally, this should be tied to a "Enable Notifications" button in settings.
      Notification.requestPermission();
    }
  }, []);

  // 2. Listen for new messages
  useEffect(() => {
    if (messages.length > prevMessagesLength.current) {
        const newMsg = messages[messages.length - 1];
        
        // Check if it's an incoming message for the current user
        if (user && newMsg.receiverId === user.id && newMsg.senderId !== user.id) {
            const sender = users.find(u => u.id === newMsg.senderId);
            if (sender) {
                // A: In-App Toast (Always show if not on Chat screen or strictly for visual feedback)
                // We show this to ensure the user sees it even if they don't have system notifications enabled
                showNotification({
                    title: sender.name,
                    message: newMsg.content,
                    avatar: sender.avatarUrl,
                    type: 'message'
                });

                // Play sound if possible (requires user interaction with document first)
                if (audioRef.current) {
                    audioRef.current.play().catch(e => console.log("Audio play blocked until user interaction"));
                }

                // B: Browser/System Notification (For background/minimized state)
                // Trigger if document is hidden OR if user is not on the chat screen
                const shouldNotifySystem = document.hidden || location.pathname !== '/chat';
                
                if (shouldNotifySystem && 'Notification' in window && Notification.permission === 'granted') {
                    const systemNotification = new Notification(`Nova mensagem de ${sender.name}`, {
                        body: newMsg.content,
                        icon: sender.avatarUrl || 'https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=' + encodeURIComponent(sender.name),
                        silent: true, // We handle sound manually via Audio API for consistency
                        tag: `deskflow-chat-${sender.id}`, // Group notifications by sender
                        renotify: true, // Vibrate/Alert again even if a notification from this sender is already open
                        vibrate: [200, 100, 200] // Vibration pattern for mobile
                    } as any);

                    systemNotification.onclick = () => {
                        window.focus();
                        navigate('/chat');
                        systemNotification.close();
                    };
                }
            }
        }
    }
    prevMessagesLength.current = messages.length;
  }, [messages, user, users, showNotification, navigate, location.pathname]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getRoleLabel = (role?: Role) => {
    switch(role) {
      case Role.ADMIN: return 'Administrador';
      case Role.TECHNICIAN: return 'Técnico de TI';
      case Role.EMPLOYEE: return 'Colaborador';
      default: return '';
    }
  };

  const NavItem = ({ to, icon: Icon, label, badgeCount }: { to: string; icon: any; label: string; badgeCount?: number }) => {
    const isActive = location.pathname === to || (to !== '/' && location.pathname.startsWith(to));
    return (
      <Link
        to={to}
        onClick={() => setIsMobileMenuOpen(false)}
        className={`group flex items-center justify-between px-4 py-3.5 rounded-xl transition-all duration-300 relative overflow-hidden ${
          isActive 
            ? 'bg-blue-600/20 text-blue-100 shadow-[inset_0px_1px_0px_0px_rgba(255,255,255,0.1)]' 
            : 'text-slate-400 hover:text-white hover:bg-white/5'
        }`}
      >
        {/* Active Indicator Bar */}
        {isActive && <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500 rounded-r-full shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>}

        <div className="flex items-center space-x-3 z-10">
          <Icon size={20} className={`transition-transform duration-300 ${isActive ? 'scale-110 text-blue-400' : 'group-hover:scale-110'}`} />
          <span className={`font-medium tracking-wide ${isActive ? 'font-semibold' : ''}`}>{label}</span>
        </div>

        {/* Badge for Notifications */}
        {badgeCount !== undefined && badgeCount > 0 && (
          <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-lg shadow-red-500/40 animate-pulse">
            {badgeCount > 99 ? '99+' : badgeCount}
          </span>
        )}
      </Link>
    );
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
        
      {/* Toast Container */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-3 pointer-events-none">
        {notifications.map(n => (
            <Toast 
                key={n.id}
                id={n.id}
                title={n.title}
                message={n.message}
                avatar={n.avatar}
                onClose={removeNotification}
                onClick={() => {
                    navigate('/chat');
                    removeNotification(n.id);
                }}
            />
        ))}
      </div>

      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-72 bg-slate-900 border-r border-slate-800 shadow-2xl z-20 relative">
        {/* Logo Area */}
        <div className="p-8 pb-8 flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
            <ShieldCheck className="text-white" size={20} />
          </div>
          <div>
             <h1 className="text-xl font-bold text-white tracking-tight leading-none">DeskFlow</h1>
             <span className="text-[10px] text-blue-400 font-semibold uppercase tracking-widest">Enterprise</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 space-y-1.5 overflow-y-auto custom-scrollbar">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-widest px-4 mb-4 mt-2">Menu Principal</div>
          <NavItem to="/" icon={LayoutDashboard} label="Dashboard" />
          <NavItem to="/tickets" icon={Ticket} label="Chamados" />
          <NavItem to="/chat" icon={MessageSquare} label="Chat" badgeCount={totalUnreadCount} />
          
          <div className="text-xs font-bold text-slate-500 uppercase tracking-widest px-4 mb-4 mt-6">Recursos</div>
          <NavItem to="/knowledge" icon={BookOpen} label="Base de Conhecimento" />
          <NavItem to="/assets" icon={Monitor} label="Inventário" />
          <NavItem to="/status" icon={Activity} label="Status de Serviços" />
        </nav>

        {/* User Profile Footer */}
        <div className="p-4 bg-slate-900/50 backdrop-blur-sm border-t border-slate-800/50">
          <div className="flex items-center p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors group cursor-pointer">
             <div className="relative w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center overflow-hidden ring-2 ring-transparent group-hover:ring-blue-500/50 transition-all">
                {user?.avatarUrl ? <img src={user.avatarUrl} alt="User" className="object-cover w-full h-full" /> : <UserIcon size={18} className="text-slate-400" />}
                <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-slate-800 rounded-full"></div>
             </div>
             <div className="ml-3 overflow-hidden flex-1">
               <p className="text-sm font-bold text-slate-200 truncate group-hover:text-white transition-colors">{user?.name}</p>
               <p className="text-xs text-slate-500 truncate capitalize">{getRoleLabel(user?.role)}</p>
             </div>
             <button
                onClick={handleLogout}
                className="ml-2 text-slate-500 hover:text-red-400 transition-colors p-2 rounded-lg hover:bg-white/5"
                title="Sair"
             >
                <LogOut size={18} />
             </button>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed w-full h-16 bg-slate-900 text-white z-30 flex items-center justify-between px-4 shadow-lg">
         <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <ShieldCheck size={16} />
            </div>
            <span className="font-bold text-lg">DeskFlow</span>
         </div>
         <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 active:bg-slate-800 rounded-lg">
           {isMobileMenuOpen ? <X /> : <Menu />}
         </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-slate-900 z-20 pt-20 px-4 animate-[fadeIn_0.2s_ease-out]">
           <nav className="space-y-2">
            <NavItem to="/" icon={LayoutDashboard} label="Dashboard" />
            <NavItem to="/tickets" icon={Ticket} label="Chamados" />
            <NavItem to="/chat" icon={MessageSquare} label="Chat" badgeCount={totalUnreadCount} />
            <NavItem to="/knowledge" icon={BookOpen} label="Base de Conhecimento" />
            <NavItem to="/assets" icon={Monitor} label="Inventário" />
            <NavItem to="/status" icon={Activity} label="Status de Serviços" />

            <div className="pt-8 mt-8 border-t border-slate-800">
               <div className="flex items-center mb-6 space-x-3">
                   <img src={user?.avatarUrl} className="w-10 h-10 rounded-full bg-slate-700" alt=""/>
                   <div>
                       <p className="text-white font-bold">{user?.name}</p>
                       <p className="text-slate-400 text-xs">{getRoleLabel(user?.role)}</p>
                   </div>
               </div>
                <button
                onClick={handleLogout}
                className="flex w-full items-center justify-center space-x-2 px-4 py-3 text-white bg-red-600/10 border border-red-600/30 rounded-xl hover:bg-red-600 hover:text-white transition-all"
                >
                <LogOut size={18} />
                <span className="font-medium">Sair do Sistema</span>
                </button>
            </div>
           </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto overflow-x-hidden md:pt-0 pt-16 relative">
        <div className="container mx-auto p-4 md:p-8 max-w-7xl min-h-full">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;

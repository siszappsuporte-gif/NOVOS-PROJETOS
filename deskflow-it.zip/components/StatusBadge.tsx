import React from 'react';
import { TicketStatus, TicketPriority } from '../types';

export const StatusBadge: React.FC<{ status: TicketStatus }> = ({ status }) => {
  const styles = {
    [TicketStatus.OPEN]: 'bg-[#e0f2fe] text-[#0369a1] border-blue-200',
    [TicketStatus.IN_PROGRESS]: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    [TicketStatus.WAITING_USER]: 'bg-purple-100 text-purple-800 border-purple-200',
    [TicketStatus.RESOLVED]: 'bg-green-100 text-green-800 border-green-200',
    [TicketStatus.CLOSED]: 'bg-gray-100 text-gray-800 border-gray-200',
  };

  const labels = {
    [TicketStatus.OPEN]: 'Aberto',
    [TicketStatus.IN_PROGRESS]: 'Em Andamento',
    [TicketStatus.WAITING_USER]: 'Aguardando Usuário',
    [TicketStatus.RESOLVED]: 'Resolvido',
    [TicketStatus.CLOSED]: 'Encerrado',
  };

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border-2 ${styles[status]}`}>
      {labels[status]}
    </span>
  );
};

export const PriorityBadge: React.FC<{ priority: TicketPriority }> = ({ priority }) => {
  const styles = {
    [TicketPriority.LOW]: 'bg-slate-100 text-slate-700',
    [TicketPriority.MEDIUM]: 'bg-blue-50 text-blue-700',
    [TicketPriority.HIGH]: 'bg-orange-50 text-orange-700',
    [TicketPriority.CRITICAL]: 'bg-red-50 text-red-700 font-bold',
  };

  const labels = {
    [TicketPriority.LOW]: 'Baixa',
    [TicketPriority.MEDIUM]: 'Média',
    [TicketPriority.HIGH]: 'Alta',
    [TicketPriority.CRITICAL]: 'Crítica',
  };

  return (
    <span className={`px-2 py-0.5 rounded text-xs font-medium ${styles[priority]}`}>
      {labels[priority]}
    </span>
  );
};
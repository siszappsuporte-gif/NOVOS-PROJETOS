import React, { useEffect } from 'react';
import { X, MessageSquare } from 'lucide-react';

export interface ToastProps {
  id: string;
  title: string;
  message: string;
  avatar?: string;
  onClose: (id: string) => void;
  onClick?: () => void;
}

const Toast: React.FC<ToastProps> = ({ id, title, message, avatar, onClose, onClick }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose(id);
    }, 5000); // Auto close after 5 seconds

    return () => clearTimeout(timer);
  }, [id, onClose]);

  return (
    <div 
      className="bg-white rounded-xl shadow-2xl border border-slate-100 p-4 w-80 md:w-96 flex items-start gap-4 animate-[slideInRight_0.4s_ease-out] cursor-pointer hover:bg-slate-50 transition-colors relative pointer-events-auto"
      onClick={onClick}
    >
      <button 
        onClick={(e) => { e.stopPropagation(); onClose(id); }}
        className="absolute top-2 right-2 text-slate-300 hover:text-slate-500 transition-colors"
      >
        <X size={16} />
      </button>

      <div className="shrink-0">
        {avatar ? (
          <div className="w-10 h-10 rounded-full overflow-hidden ring-2 ring-slate-50">
            <img src={avatar} alt="" className="w-full h-full object-cover" />
          </div>
        ) : (
          <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
            <MessageSquare size={20} />
          </div>
        )}
      </div>

      <div className="flex-1 min-w-0 pr-4">
        <h4 className="font-bold text-sm text-slate-800 truncate">{title}</h4>
        <p className="text-sm text-slate-500 line-clamp-2 mt-0.5">{message}</p>
      </div>
      
      {/* Blue dot indicator */}
      <div className="absolute top-4 right-8 w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
    </div>
  );
};

export default Toast;
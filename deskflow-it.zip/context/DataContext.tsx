
import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Ticket, ChatMessage, User, TicketStatus, Article, Asset, ServiceHealth } from '../types';
import { MOCK_TICKETS, MOCK_MESSAGES, MOCK_USERS, MOCK_ARTICLES, MOCK_ASSETS, MOCK_SERVICES } from '../mockData';

interface TypingState {
  senderId: string;   // Who is typing
  receiverId: string; // Who is receiving
}

interface ConnectionInfo {
  type: string;
  downlink: number;
}

interface DataContextType {
  tickets: Ticket[];
  messages: ChatMessage[];
  users: User[];
  articles: Article[];
  assets: Asset[]; 
  services: ServiceHealth[]; 
  starredUserIds: string[];
  
  // Network Stats
  latency: number | null;
  isOnline: boolean;
  connectionInfo: ConnectionInfo | null;
  verificarLatencia: () => Promise<void>; // Nova função exposta

  createTicket: (ticket: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'comments'>) => void;
  updateTicketStatus: (ticketId: string, status: TicketStatus, userId: string) => void;
  assignTicket: (ticketId: string, assigneeId: string | null, userId: string) => void;
  addComment: (ticketId: string, content: string, userId: string) => void;
  sendMessage: (senderId: string, receiverId: string, content: string) => void;
  getMessagesBetween: (user1Id: string, user2Id: string) => ChatMessage[];
  toggleUserStar: (userId: string) => void;
  markMessagesAsRead: (senderId: string, receiverId: string) => void;
  getUnreadCount: (currentUserId: string, senderId: string) => number;
  checkIsTyping: (senderId: string, receiverId: string) => boolean;
  toggleArticleLike: (articleId: string) => void;
  
  // Asset CRUD
  addAsset: (asset: Asset) => void;
  deleteAsset: (assetId: string) => void;

  // Service CRUD
  addService: (service: ServiceHealth) => void;
  deleteService: (serviceId: string) => void;

  // Article CRUD
  addArticle: (article: Article) => void;
  updateArticle: (article: Article) => void;
  deleteArticle: (articleId: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [tickets, setTickets] = useState<Ticket[]>(MOCK_TICKETS);
  const [messages, setMessages] = useState<ChatMessage[]>(MOCK_MESSAGES);
  const [users] = useState<User[]>(MOCK_USERS);
  const [articles, setArticles] = useState<Article[]>(MOCK_ARTICLES);
  const [assets, setAssets] = useState<Asset[]>(MOCK_ASSETS); 
  const [services, setServices] = useState<ServiceHealth[]>(MOCK_SERVICES); 
  const [starredUserIds, setStarredUserIds] = useState<string[]>([]);
  const [typingStates, setTypingStates] = useState<TypingState[]>([]);

  // Network State
  const [latency, setLatency] = useState<number | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [connectionInfo, setConnectionInfo] = useState<ConnectionInfo | null>(null);

  // Função dedicada para verificar latência (Ping)
  const verificarLatencia = useCallback(async () => {
    const start = Date.now();
    try {
      // Faz um "Ping" usando HEAD request para evitar baixar corpo da página
      // 'no-store' garante que não pegaremos do cache, medindo a rede real
      await fetch(window.location.href, { method: 'HEAD', cache: 'no-store' });
      const end = Date.now();
      const rtt = end - start;
      setLatency(rtt);
      if (!isOnline) setIsOnline(true);
    } catch (e) {
      setLatency(null); // Timeout ou erro de rede
      setIsOnline(false);
    }
  }, [isOnline]);

  // Global Network Monitoring Logic
  useEffect(() => {
    // 1. Online/Offline Handlers
    const handleOnline = () => { setIsOnline(true); verificarLatencia(); };
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // 2. Connection Info (Network Information API)
    const updateConnectionInfo = () => {
      const nav = navigator as any;
      const conn = nav.connection || nav.mozConnection || nav.webkitConnection;
      if (conn) {
        setConnectionInfo({
          type: conn.effectiveType || 'wifi',
          downlink: conn.downlink || 0
        });
      }
    };

    // Initial checks
    verificarLatencia();
    updateConnectionInfo();

    // 3. Intervalo de 5 segundos para verificar latência
    const latencyInterval = setInterval(verificarLatencia, 5000); 
    
    if ((navigator as any).connection) {
        (navigator as any).connection.addEventListener('change', updateConnectionInfo);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(latencyInterval);
      if ((navigator as any).connection) {
        (navigator as any).connection.removeEventListener('change', updateConnectionInfo);
      }
    };
  }, [verificarLatencia]);

  const createTicket = (ticketData: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'comments'>) => {
    const newTicket: Ticket = {
      ...ticketData,
      id: `T-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      comments: [{
        id: `sys-${Date.now()}`,
        ticketId: '',
        userId: ticketData.requesterId,
        content: `Chamado criado com prioridade ${ticketData.priority}`,
        createdAt: new Date().toISOString(),
        type: 'SYSTEM_LOG'
      }]
    };
    setTickets(prev => [newTicket, ...prev]);
  };

  const updateTicketStatus = (ticketId: string, status: TicketStatus, userId: string) => {
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          status,
          updatedAt: new Date().toISOString(),
          comments: [...t.comments, {
            id: `sys-${Date.now()}`,
            ticketId,
            userId,
            content: `Status alterado para ${status}`,
            createdAt: new Date().toISOString(),
            type: 'SYSTEM_LOG'
          }]
        };
      }
      return t;
    }));
  };

  const assignTicket = (ticketId: string, assigneeId: string | null, userId: string) => {
    const assignee = users.find(u => u.id === assigneeId);
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          assigneeId: assigneeId || undefined,
          updatedAt: new Date().toISOString(),
          comments: [...t.comments, {
            id: `sys-${Date.now()}`,
            ticketId,
            userId,
            content: assigneeId ? `Atribuído a ${assignee?.name}` : 'Responsável removido',
            createdAt: new Date().toISOString(),
            type: 'SYSTEM_LOG'
          }]
        };
      }
      return t;
    }));
  };

  const addComment = (ticketId: string, content: string, userId: string) => {
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          updatedAt: new Date().toISOString(),
          comments: [...t.comments, {
            id: `c-${Date.now()}`,
            ticketId,
            userId,
            content,
            createdAt: new Date().toISOString(),
            type: 'COMMENT'
          }]
        };
      }
      return t;
    }));
  };

  const sendMessage = (senderId: string, receiverId: string, content: string) => {
    const newMessage: ChatMessage = {
      id: `m-${Date.now()}`,
      senderId,
      receiverId,
      content,
      timestamp: new Date().toISOString(),
      read: false
    };
    setMessages(prev => [...prev, newMessage]);

    setTimeout(() => {
        setTypingStates(prev => [...prev, { senderId: receiverId, receiverId: senderId }]);
        setTimeout(() => {
            setTypingStates(prev => prev.filter(ts => !(ts.senderId === receiverId && ts.receiverId === senderId)));
            const replies = [
                "Recebi sua mensagem. Vou verificar isso agora.",
                "Obrigado pelo contato. Já te retorno.",
                "Pode me dar mais detalhes sobre isso?",
                "Entendido. Em breve te dou uma posição.",
                "Ok, estou analisando aqui."
            ];
            const randomReply = replies[Math.floor(Math.random() * replies.length)];
            const replyMsg: ChatMessage = {
                id: `m-reply-${Date.now()}`,
                senderId: receiverId, 
                receiverId: senderId, 
                content: randomReply,
                timestamp: new Date().toISOString(),
                read: false
            };
            setMessages(prev => [...prev, replyMsg]);
        }, 2500); 
    }, 1000); 
  };

  const getMessagesBetween = (user1Id: string, user2Id: string) => {
    return messages.filter(
      m => (m.senderId === user1Id && m.receiverId === user2Id) ||
           (m.senderId === user2Id && m.receiverId === user1Id)
    ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  };

  const markMessagesAsRead = (senderId: string, receiverId: string) => {
    setMessages(prev => prev.map(m => {
      if (m.senderId === senderId && m.receiverId === receiverId && !m.read) {
        return { ...m, read: true };
      }
      return m;
    }));
  };

  const getUnreadCount = (currentUserId: string, senderId: string) => {
    return messages.filter(m => m.receiverId === currentUserId && m.senderId === senderId && !m.read).length;
  };

  const toggleUserStar = (userId: string) => {
    setStarredUserIds(prev => 
      prev.includes(userId) 
        ? prev.filter(id => id !== userId) 
        : [...prev, userId]
    );
  };

  const checkIsTyping = (senderId: string, receiverId: string) => {
    return typingStates.some(ts => ts.senderId === senderId && ts.receiverId === receiverId);
  };

  const toggleArticleLike = (articleId: string) => {
    setArticles(prev => prev.map(a => 
        a.id === articleId ? { ...a, likes: a.likes + 1 } : a
    ));
  };

  // --- CRUD OPERATIONS ---

  const addAsset = (asset: Asset) => {
    setAssets(prev => [asset, ...prev]);
  };

  const deleteAsset = (assetId: string) => {
    setAssets(prev => prev.filter(a => a.id !== assetId));
  };

  const addService = (service: ServiceHealth) => {
    setServices(prev => [service, ...prev]);
  };

  const deleteService = (serviceId: string) => {
    setServices(prev => prev.filter(s => s.id !== serviceId));
  };

  const addArticle = (article: Article) => {
    setArticles(prev => [article, ...prev]);
  };

  const updateArticle = (updatedArticle: Article) => {
    setArticles(prev => prev.map(a => a.id === updatedArticle.id ? updatedArticle : a));
  };

  const deleteArticle = (articleId: string) => {
    setArticles(prev => prev.filter(a => a.id !== articleId));
  };

  return (
    <DataContext.Provider value={{
      tickets,
      messages,
      users,
      articles,
      assets,
      services,
      starredUserIds,
      latency,
      isOnline,
      connectionInfo,
      verificarLatencia,
      createTicket,
      updateTicketStatus,
      assignTicket,
      addComment,
      sendMessage,
      getMessagesBetween,
      toggleUserStar,
      markMessagesAsRead,
      getUnreadCount,
      checkIsTyping,
      toggleArticleLike,
      addAsset,
      deleteAsset,
      addService,
      deleteService,
      addArticle,
      updateArticle,
      deleteArticle
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error("useData must be used within DataProvider");
  return context;
};

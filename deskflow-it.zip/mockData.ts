
import { Role, Ticket, TicketCategory, TicketPriority, TicketStatus, User, ChatMessage, Article, Asset, AssetType, AssetStatus, ServiceHealth, ServiceHealthStatus } from './types';

export const MOCK_USERS: User[] = [
  {
    id: 'u-bot',
    name: 'DeskFlow Assistant',
    email: 'bot@deskflow.com',
    role: Role.ADMIN,
    department: 'Automated Support',
    isOnline: true,
    avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=deskflow'
  },
  {
    id: 'u1',
    name: 'Jane Doe',
    email: 'jane@company.com',
    role: Role.EMPLOYEE,
    department: 'Marketing',
    isOnline: true,
    avatarUrl: 'https://picsum.photos/200/200?random=1'
  },
  {
    id: 'u2',
    name: 'John Smith',
    email: 'john@company.com',
    role: Role.TECHNICIAN,
    department: 'Suporte TI',
    isOnline: true,
    avatarUrl: 'https://picsum.photos/200/200?random=2'
  },
  {
    id: 'u3',
    name: 'Sarah Admin',
    email: 'sarah@company.com',
    role: Role.ADMIN,
    department: 'Gestão de TI',
    isOnline: false,
    avatarUrl: 'https://picsum.photos/200/200?random=3'
  },
  {
    id: 'u4',
    name: 'Mike Sales',
    email: 'mike@company.com',
    role: Role.EMPLOYEE,
    department: 'Vendas',
    isOnline: true,
    avatarUrl: 'https://picsum.photos/200/200?random=4'
  }
];

export const MOCK_TICKETS: Ticket[] = [
  {
    id: 'T-1001',
    title: 'Teclado do Notebook com defeito',
    description: 'Minha barra de espaço está travando repetidamente. Está difícil digitar.',
    category: TicketCategory.HARDWARE,
    priority: TicketPriority.MEDIUM,
    status: TicketStatus.IN_PROGRESS,
    requesterId: 'u1',
    assigneeId: 'u2',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 3600000).toISOString(),
    comments: [
      {
        id: 'c1',
        ticketId: 'T-1001',
        userId: 'u1',
        content: 'Chamado inicial registrado.',
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        type: 'SYSTEM_LOG'
      },
      {
        id: 'c2',
        ticketId: 'T-1001',
        userId: 'u2',
        content: 'Olá Jane, posso passar na sua mesa às 14h hoje para verificar.',
        createdAt: new Date(Date.now() - 86000000).toISOString(),
        type: 'COMMENT'
      }
    ]
  },
  {
    id: 'T-1002',
    title: 'Falha na conexão VPN',
    description: 'Não consigo conectar à VPN segura de casa.',
    category: TicketCategory.NETWORK,
    priority: TicketPriority.HIGH,
    status: TicketStatus.OPEN,
    requesterId: 'u4',
    createdAt: new Date(Date.now() - 43200000).toISOString(),
    updatedAt: new Date(Date.now() - 43200000).toISOString(),
    comments: []
  },
  {
    id: 'T-1003',
    title: 'Solicitação de licença Adobe',
    description: 'Preciso do Adobe Acrobat Pro para um novo projeto que começa segunda-feira.',
    category: TicketCategory.SOFTWARE,
    priority: TicketPriority.LOW,
    status: TicketStatus.RESOLVED,
    requesterId: 'u1',
    assigneeId: 'u3',
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    comments: [
      {
        id: 'c3',
        ticketId: 'T-1003',
        userId: 'u3',
        content: 'Licença atribuída. Por favor, reinicie o Creative Cloud.',
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        type: 'COMMENT'
      }
    ]
  },
   {
    id: 'T-1004',
    title: 'Queda de servidor no 3º andar',
    description: 'O servidor de impressão local parece estar fora do ar.',
    category: TicketCategory.NETWORK,
    priority: TicketPriority.CRITICAL,
    status: TicketStatus.OPEN,
    requesterId: 'u4',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    comments: []
  }
];

export const MOCK_MESSAGES: ChatMessage[] = [
  {
    id: 'm1',
    senderId: 'u2',
    receiverId: 'u1',
    content: 'Oi Jane, sobre aquele problema do teclado...',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    read: true
  },
  {
    id: 'm2',
    senderId: 'u1',
    receiverId: 'u2',
    content: 'Sim? Você ainda vem às 14h?',
    timestamp: new Date(Date.now() - 3500000).toISOString(),
    read: true
  },
  {
    id: 'm3',
    senderId: 'u-bot',
    receiverId: 'u1',
    content: 'Olá! Eu sou o assistente virtual do DeskFlow. Como posso ajudar você hoje?',
    timestamp: new Date(Date.now() - 10000000).toISOString(),
    read: true
  }
];

export const MOCK_ARTICLES: Article[] = [
  {
    id: 'kb-1',
    title: 'Como configurar a VPN Corporativa',
    excerpt: 'Guia passo-a-passo para conectar na rede segura utilizando o GlobalProtect.',
    content: '1. Baixe o cliente GlobalProtect no portal de softwares.\n2. Instale o aplicativo.\n3. No campo portal, digite "vpn.company.com".\n4. Insira suas credenciais de rede.\n5. Aprove a notificação de MFA no seu celular.',
    category: TicketCategory.NETWORK,
    authorId: 'u3',
    likes: 145,
    views: 1205,
    createdAt: new Date(Date.now() - 86400000 * 30).toISOString()
  },
  {
    id: 'kb-2',
    title: 'Solicitação de Novos Equipamentos',
    excerpt: 'Política e procedimento para solicitar monitores, mouses ou notebooks.',
    content: 'Para solicitar novos equipamentos, abra um chamado na categoria Hardware. É necessária aprovação do gerente do centro de custo para itens acima de R$ 500,00. O prazo de entrega padrão é de 5 dias úteis.',
    category: TicketCategory.HARDWARE,
    authorId: 'u3',
    likes: 89,
    views: 850,
    createdAt: new Date(Date.now() - 86400000 * 60).toISOString()
  },
  {
    id: 'kb-3',
    title: 'Erro de Certificado no Outlook',
    excerpt: 'Solução para o pop-up recorrente de certificado inválido no e-mail.',
    content: 'Este erro geralmente ocorre após a alteração de senha de rede. Para corrigir:\n1. Feche o Outlook.\n2. Vá em Painel de Controle > Gerenciador de Credenciais.\n3. Remova as credenciais salvas do MicrosoftOffice16.\n4. Abra o Outlook e digite sua nova senha.',
    category: TicketCategory.SOFTWARE,
    authorId: 'u2',
    likes: 230,
    views: 3400,
    createdAt: new Date(Date.now() - 86400000 * 15).toISOString()
  },
  {
    id: 'kb-4',
    title: 'Acesso ao SAP - Reset de Senha',
    excerpt: 'Como desbloquear seu usuário SAP ou resetar a senha via portal.',
    content: 'O reset de senha do SAP não é sincronizado com o Windows. Utilize o portal self-service em sap-portal.company.com ou abra um chamado na categoria Acesso se estiver bloqueado.',
    category: TicketCategory.ACCESS,
    authorId: 'u2',
    likes: 56,
    views: 420,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString()
  }
];

export const MOCK_ASSETS: Asset[] = [
  {
    id: 'AST-001',
    name: 'Dell Latitude 5420',
    type: AssetType.LAPTOP,
    serialNumber: 'DJK9201L',
    status: AssetStatus.IN_USE,
    assignedToUserId: 'u1',
    purchaseDate: '2023-05-10',
    model: 'Latitude 5420 / i7 / 16GB'
  },
  {
    id: 'AST-002',
    name: 'Dell Latitude 5420',
    type: AssetType.LAPTOP,
    serialNumber: 'D88201L',
    status: AssetStatus.IN_USE,
    assignedToUserId: 'u2',
    purchaseDate: '2023-05-10',
    model: 'Latitude 5420 / i7 / 16GB'
  },
  {
    id: 'AST-003',
    name: 'Monitor Dell P2419H',
    type: AssetType.MONITOR,
    serialNumber: 'CN-001',
    status: AssetStatus.AVAILABLE,
    purchaseDate: '2022-11-15',
    model: '24 inch IPS'
  },
  {
    id: 'AST-004',
    name: 'Adobe Creative Cloud',
    type: AssetType.SOFTWARE,
    serialNumber: 'LIC-9921',
    status: AssetStatus.IN_USE,
    assignedToUserId: 'u1',
    purchaseDate: '2024-01-01',
    model: 'All Apps Subscription'
  },
  {
    id: 'AST-005',
    name: 'MacBook Pro 16"',
    type: AssetType.LAPTOP,
    serialNumber: 'MK-2901',
    status: AssetStatus.MAINTENANCE,
    purchaseDate: '2023-08-20',
    model: 'M2 Pro / 32GB'
  }
];

export const MOCK_SERVICES: ServiceHealth[] = [
  {
    id: 'srv-1',
    name: 'E-mail Corporativo (Exchange)',
    status: ServiceHealthStatus.OPERATIONAL,
    uptime: 99.98,
    description: 'Envio e recebimento de e-mails'
  },
  {
    id: 'srv-2',
    name: 'ERP Financeiro (SAP)',
    status: ServiceHealthStatus.DEGRADED,
    uptime: 98.50,
    lastIncident: 'Lentidão no módulo de faturamento',
    description: 'Sistema de gestão financeira e contábil'
  },
  {
    id: 'srv-3',
    name: 'Internet / Wi-Fi',
    status: ServiceHealthStatus.OPERATIONAL,
    uptime: 99.99,
    description: 'Conectividade de rede interna e externa'
  },
  {
    id: 'srv-4',
    name: 'VPN Acesso Remoto',
    status: ServiceHealthStatus.OPERATIONAL,
    uptime: 99.95,
    description: 'Acesso seguro externo'
  },
  {
    id: 'srv-5',
    name: 'Servidor de Arquivos (Sharepoint)',
    status: ServiceHealthStatus.MAINTENANCE,
    uptime: 100,
    lastIncident: 'Manutenção programada até 18h',
    description: 'Armazenamento de documentos'
  }
];


import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Asset, AssetType, AssetStatus, Role } from '../types';
import { Monitor, Laptop, Box, Server, Search, Plus, Trash2, Calendar, User, X } from 'lucide-react';

const Assets: React.FC = () => {
  const { assets, users, addAsset, deleteAsset } = useData();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('ALL');
  
  // Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newAsset, setNewAsset] = useState<Partial<Asset>>({
      type: AssetType.LAPTOP,
      status: AssetStatus.AVAILABLE
  });

  const canEdit = user?.role === Role.ADMIN || user?.role === Role.TECHNICIAN;

  const filteredAssets = assets.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          asset.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          asset.model.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'ALL' || asset.type === filterType;
    
    return matchesSearch && matchesType;
  });

  const handleAddAsset = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newAsset.name || !newAsset.serialNumber || !newAsset.model) return;

      const asset: Asset = {
          id: `AST-${Math.floor(Math.random() * 10000)}`,
          name: newAsset.name,
          type: newAsset.type as AssetType,
          serialNumber: newAsset.serialNumber,
          model: newAsset.model,
          status: newAsset.status as AssetStatus,
          purchaseDate: new Date().toISOString(),
          assignedToUserId: newAsset.assignedToUserId
      };

      addAsset(asset);
      setShowAddModal(false);
      setNewAsset({ type: AssetType.LAPTOP, status: AssetStatus.AVAILABLE });
  };

  const getStatusColor = (status: AssetStatus) => {
    switch (status) {
      case AssetStatus.AVAILABLE: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case AssetStatus.IN_USE: return 'bg-blue-100 text-blue-700 border-blue-200';
      case AssetStatus.MAINTENANCE: return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case AssetStatus.RETIRED: return 'bg-gray-100 text-gray-700 border-gray-200';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const getStatusLabel = (status: AssetStatus) => {
    switch (status) {
      case AssetStatus.AVAILABLE: return 'Disponível';
      case AssetStatus.IN_USE: return 'Em Uso';
      case AssetStatus.MAINTENANCE: return 'Manutenção';
      case AssetStatus.RETIRED: return 'Aposentado';
      default: return status;
    }
  };

  const getIcon = (type: AssetType) => {
    switch(type) {
      case AssetType.LAPTOP: return <Laptop size={20} />;
      case AssetType.MONITOR: return <Monitor size={20} />;
      case AssetType.SOFTWARE: return <Box size={20} />;
      case AssetType.DESKTOP: return <Server size={20} />;
      default: return <Box size={20} />;
    }
  };

  const getUserName = (userId?: string) => {
    if (!userId) return '-';
    const u = users.find(user => user.id === userId);
    return u ? u.name : 'Usuário desconhecido';
  };

  return (
    <div className="space-y-6 animate-[fadeIn_0.5s_ease-out]">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
             <div>
                <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Inventário de Ativos</h1>
                <p className="text-slate-500 font-medium mt-1">Gestão de hardware e licenças de software.</p>
             </div>
             {canEdit && (
                 <button 
                    onClick={() => setShowAddModal(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl flex items-center shadow-lg shadow-blue-500/30 transition-all font-bold text-sm"
                 >
                    <Plus size={18} className="mr-2" /> Novo Ativo
                 </button>
             )}
        </div>

        {/* Toolbar */}
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
                <Search className="absolute left-4 top-3 text-slate-400" size={18} />
                <input
                    type="text"
                    placeholder="Buscar por nome, serial ou modelo..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-11 pr-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/50 bg-slate-50 focus:bg-white transition-all"
                />
            </div>
            <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
                {['ALL', ...Object.values(AssetType)].map((type) => (
                    <button
                        key={type}
                        onClick={() => setFilterType(type)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors border ${
                            filterType === type 
                            ? 'bg-blue-600 text-white border-blue-600' 
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                    >
                        {type === 'ALL' ? 'Todos' : type}
                    </button>
                ))}
            </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAssets.map(asset => (
                <div key={asset.id} className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-all group relative">
                    <div className="p-5">
                        <div className="flex justify-between items-start mb-4">
                             <div className="p-3 bg-slate-100 text-slate-600 rounded-lg group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                                 {getIcon(asset.type)}
                             </div>
                             <div className="flex gap-2">
                                <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${getStatusColor(asset.status)}`}>
                                    {getStatusLabel(asset.status)}
                                </span>
                                {canEdit && (
                                    <button 
                                        onClick={() => deleteAsset(asset.id)}
                                        className="p-1 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                                        title="Remover Ativo"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                )}
                             </div>
                        </div>
                        
                        <h3 className="text-lg font-bold text-slate-800 mb-1">{asset.name}</h3>
                        <p className="text-sm text-slate-500 mb-4 font-mono">{asset.model}</p>

                        <div className="space-y-2 text-sm border-t border-slate-50 pt-3">
                            <div className="flex justify-between">
                                <span className="text-slate-400 flex items-center gap-2"><Box size={14}/> Serial:</span>
                                <span className="font-mono text-slate-600">{asset.serialNumber}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-slate-400 flex items-center gap-2"><Calendar size={14}/> Compra:</span>
                                <span className="text-slate-600">{new Date(asset.purchaseDate).toLocaleDateString()}</span>
                            </div>
                             {asset.assignedToUserId && (
                                <div className="flex justify-between bg-slate-50 p-2 rounded-lg mt-2">
                                    <span className="text-slate-400 flex items-center gap-2"><User size={14}/> Usuário:</span>
                                    <span className="font-bold text-slate-700">{getUserName(asset.assignedToUserId)}</span>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            ))}

            {filteredAssets.length === 0 && (
                <div className="col-span-full py-16 text-center text-slate-400">
                    <Search size={48} className="mx-auto mb-4 opacity-20" />
                    <p>Nenhum ativo encontrado.</p>
                </div>
            )}
        </div>

        {/* Add Modal */}
        {showAddModal && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden animate-[scaleIn_0.2s_ease-out]">
                    <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                        <h3 className="font-bold text-lg text-slate-800">Novo Ativo</h3>
                        <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                            <X size={20} />
                        </button>
                    </div>
                    <form onSubmit={handleAddAsset} className="p-6 space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome do Ativo</label>
                            <input 
                                required
                                className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                value={newAsset.name || ''}
                                onChange={e => setNewAsset({...newAsset, name: e.target.value})}
                                placeholder="Ex: Dell Inspiron 15"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tipo</label>
                                <select 
                                    className="w-full border border-slate-200 rounded-lg p-2.5 bg-white outline-none"
                                    value={newAsset.type}
                                    onChange={e => setNewAsset({...newAsset, type: e.target.value as AssetType})}
                                >
                                    {Object.values(AssetType).map(t => <option key={t} value={t}>{t}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status</label>
                                <select 
                                    className="w-full border border-slate-200 rounded-lg p-2.5 bg-white outline-none"
                                    value={newAsset.status}
                                    onChange={e => setNewAsset({...newAsset, status: e.target.value as AssetStatus})}
                                >
                                    {Object.values(AssetStatus).map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Serial Number</label>
                            <input 
                                required
                                className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                value={newAsset.serialNumber || ''}
                                onChange={e => setNewAsset({...newAsset, serialNumber: e.target.value})}
                                placeholder="Ex: XY99-2201"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Modelo / Detalhes</label>
                            <input 
                                required
                                className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                value={newAsset.model || ''}
                                onChange={e => setNewAsset({...newAsset, model: e.target.value})}
                                placeholder="Ex: 16GB RAM, i7 11th Gen"
                            />
                        </div>
                         {newAsset.status === AssetStatus.IN_USE && (
                             <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Atribuído a</label>
                                <select 
                                    className="w-full border border-slate-200 rounded-lg p-2.5 bg-white outline-none"
                                    value={newAsset.assignedToUserId || ''}
                                    onChange={e => setNewAsset({...newAsset, assignedToUserId: e.target.value})}
                                >
                                    <option value="">Selecione um usuário...</option>
                                    {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                                </select>
                            </div>
                         )}
                        <div className="pt-4 flex justify-end gap-2">
                            <button 
                                type="button"
                                onClick={() => setShowAddModal(false)}
                                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                            >
                                Cancelar
                            </button>
                            <button 
                                type="submit"
                                className="px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg font-bold"
                            >
                                Salvar Ativo
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        )}
    </div>
  );
};

export default Assets;

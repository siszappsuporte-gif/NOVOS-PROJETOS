import React, { useState, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { ChatMessage, User, TicketCategory, TicketPriority, TicketStatus } from '../types';
import { Send, Search, MoreVertical, Phone, Video, Star, CheckCheck, Check, MessageSquare, Bot } from 'lucide-react';
import { format } from 'date-fns';

interface UserListItemProps {
  user: User;
  selectedUserId: string | null;
  starredUserIds: string[];
  unreadCount: number;
  onSelect: (id: string) => void;
  onToggleStar: (id: string) => void;
}

const UserListItem: React.FC<UserListItemProps> = ({ user, selectedUserId, starredUserIds, unreadCount, onSelect, onToggleStar }) => {
  const isStarred = starredUserIds.includes(user.id);
  const isActive = selectedUserId === user.id;
  const isBot = user.id === 'u-bot';

  return (
    <button
      onClick={() => onSelect(user.id)}
      className={`w-full p-3.5 flex items-center space-x-3 transition-all duration-200 border-l-[3px] group relative hover:bg-slate-50 ${
        isActive 
          ? 'bg-blue-50/60 border-blue-600' 
          : 'border-transparent'
      }`}
    >
      <div className="relative shrink-0">
        <div className={`w-11 h-11 rounded-full overflow-hidden ring-2 shadow-sm ${isBot ? 'bg-indigo-100 ring-indigo-200' : 'bg-slate-200 ring-white'}`}>
          {isBot ? (
             <div className="w-full h-full flex items-center justify-center">
                 <img src={user.avatarUrl} alt="Bot" className="w-full h-full object-cover" />
             </div>
          ) : (
             <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover"/>
          )}
        </div>
        {user.isOnline && (
          <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white shadow-sm"></div>
        )}
      </div>
      <div className="text-left flex-1 min-w-0">
        <div className="flex justify-between items-center mb-0.5">
           <h4 className={`font-semibold text-sm truncate ${isActive ? 'text-blue-700' : 'text-slate-800'}`}>
             {user.name}
           </h4>
           {unreadCount > 0 && (
             <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center shadow-sm animate-pulse">
               {unreadCount}
             </span>
           )}
        </div>
        <p className="text-xs text-slate-500 truncate">{user.department}</p>
      </div>
      
      {/* Star Button - Updated for better visibility */}
      <div 
        onClick={(e) => {
          e.stopPropagation();
          onToggleStar(user.id);
        }}
        className={`p-2 rounded-full hover:bg-slate-200/80 transition-all cursor-pointer ${
          isStarred 
            ? 'text-yellow-400 scale-100' 
            : 'text-slate-300 hover:text-yellow-400 scale-90 hover:scale-110'
        }`}
        title={isStarred ? "Remover dos favoritos" : "Adicionar aos favoritos"}
      >
        <Star size={16} fill={isStarred ? "currentColor" : "none"} />
      </div>
    </button>
  );
};

// --- BOT LOGIC TYPES ---
type BotStep = 'INIT' | 'CATEGORY' | 'PRIORITY' | 'TITLE' | 'DESCRIPTION' | 'CONFIRMATION';

const Chat: React.FC = () => {
  const { users, messages, sendMessage, getMessagesBetween, starredUserIds, toggleUserStar, markMessagesAsRead, getUnreadCount, checkIsTyping, createTicket } = useData();
  const { user: currentUser } = useAuth();
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Bot State
  const [botStep, setBotStep] = useState<BotStep>('INIT');
  const [ticketDraft, setTicketDraft] = useState<any>({});
  const [botTyping, setBotTyping] = useState(false);

  const availableUsers = users.filter(u => u.id !== currentUser?.id);
  const BOT_ID = 'u-bot';
  
  // Filter by search
  const filteredUsers = availableUsers.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Split into Starred and Others
  const starredUsers = filteredUsers.filter(u => starredUserIds.includes(u.id));
  const otherUsers = filteredUsers.filter(u => !starredUserIds.includes(u.id));

  const sortUserFn = (a: User, b: User) => {
    // Bot always on top if not starred
    if (a.id === BOT_ID) return -1;
    if (b.id === BOT_ID) return 1;

    if (a.isOnline === b.isOnline) return a.name.localeCompare(b.name);
    return a.isOnline ? -1 : 1;
  };

  const sortedStarred = [...starredUsers].sort(sortUserFn);
  const sortedOthers = [...otherUsers].sort(sortUserFn);

  const activeChatMessages = selectedUserId && currentUser 
    ? getMessagesBetween(currentUser.id, selectedUserId) 
    : [];

  const selectedUser = users.find(u => u.id === selectedUserId);
  const isTyping = (selectedUser && currentUser && selectedUserId !== BOT_ID) 
      ? checkIsTyping(selectedUser.id, currentUser.id) 
      : botTyping; // Use local state for bot typing simulation

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeChatMessages, isTyping]); 

  // Mark as read when opening chat
  useEffect(() => {
    if (selectedUserId && currentUser) {
      markMessagesAsRead(selectedUserId, currentUser.id);
    }
  }, [selectedUserId, messages, currentUser]);

  // Reset Bot Flow when selecting the bot if conversation is empty or stale? 
  // For simplicity, we keep state in memory while component is mounted.
  useEffect(() => {
      if (selectedUserId === BOT_ID && activeChatMessages.length === 0 && botStep === 'INIT') {
          // Trigger welcome if no messages yet
          handleBotResponse('');
      }
  }, [selectedUserId]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !selectedUserId || !currentUser) return;
    
    // 1. Send User Message
    sendMessage(currentUser.id, selectedUserId, messageText);
    const sentText = messageText;
    setMessageText('');

    // 2. Check if talking to Bot
    if (selectedUserId === BOT_ID) {
        handleBotResponse(sentText);
    }
  };

  // --- BOT LOGIC ENGINE ---
  const handleBotResponse = (userLastMessage: string) => {
      if (!currentUser) return;
      setBotTyping(true);

      setTimeout(() => {
        let response = '';
        let nextStep = botStep;

        switch (botStep) {
            case 'INIT':
                response = "Olá! Sou o Assistente Virtual do DeskFlow. Para agilizar seu atendimento, vou coletar algumas informações para abrir um chamado automaticamente.\n\nPara começar, qual a Categoria do problema?\n(Responda: Hardware, Software, Rede ou Acesso)";
                nextStep = 'CATEGORY';
                break;
            
            case 'CATEGORY':
                // Simple validation
                const cat = userLastMessage.toUpperCase();
                let selectedCat = TicketCategory.OTHER;
                if (cat.includes('HARDWARE')) selectedCat = TicketCategory.HARDWARE;
                else if (cat.includes('SOFTWARE')) selectedCat = TicketCategory.SOFTWARE;
                else if (cat.includes('REDE') || cat.includes('NETWORK')) selectedCat = TicketCategory.NETWORK;
                else if (cat.includes('ACESSO') || cat.includes('ACCESS')) selectedCat = TicketCategory.ACCESS;

                setTicketDraft((prev: any) => ({ ...prev, category: selectedCat }));
                response = `Entendido, categoria definida como ${selectedCat}.\n\nQual a prioridade do problema?\n(Baixa, Média, Alta ou Crítica)`;
                nextStep = 'PRIORITY';
                break;

            case 'PRIORITY':
                const prio = userLastMessage.toUpperCase();
                let selectedPrio = TicketPriority.LOW;
                if (prio.includes('MEDIA') || prio.includes('MÉDIA')) selectedPrio = TicketPriority.MEDIUM;
                else if (prio.includes('ALTA')) selectedPrio = TicketPriority.HIGH;
                else if (prio.includes('CRITICA') || prio.includes('CRÍTICA')) selectedPrio = TicketPriority.CRITICAL;

                setTicketDraft((prev: any) => ({ ...prev, priority: selectedPrio }));
                response = "Certo. Agora, por favor, escreva um Título curto para o chamado.";
                nextStep = 'TITLE';
                break;

            case 'TITLE':
                setTicketDraft((prev: any) => ({ ...prev, title: userLastMessage }));
                response = "Ótimo. Por favor, descreva o problema detalhadamente. Quanto mais informações, melhor.";
                nextStep = 'DESCRIPTION';
                break;

            case 'DESCRIPTION':
                const desc = userLastMessage;
                // Finalize Ticket
                const finalTicket = {
                    ...ticketDraft,
                    description: desc,
                    requesterId: currentUser.id,
                    status: TicketStatus.OPEN
                };
                
                createTicket(finalTicket);
                
                response = "✅ Chamado criado com sucesso!\nUm técnico da equipe foi notificado e entrará em contato em breve.\n\nSe precisar de mais alguma coisa, basta chamar.";
                nextStep = 'INIT'; // Reset for next time
                setTicketDraft({});
                break;
                
            default:
                response = "Desculpe, não entendi. Vamos começar de novo?";
                nextStep = 'INIT';
        }

        sendMessage(BOT_ID, currentUser.id, response);
        setBotStep(nextStep);
        setBotTyping(false);

      }, 1500); // Simulated delay
  };

  return (
    <div className="h-[calc(100vh-120px)] bg-white rounded-2xl shadow-xl border border-slate-200/60 flex overflow-hidden backdrop-blur-sm">
      
      {/* Sidebar - Users */}
      <div className="w-80 border-r border-slate-200 flex flex-col bg-white">
         <div className="p-5 border-b border-slate-100">
            <h2 className="font-bold text-xl text-slate-800 mb-4 tracking-tight">Mensagens</h2>
            <div className="relative group">
              <Search className="absolute left-3 top-2.5 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={18} />
              <input 
                type="text" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar colegas..." 
                className="w-full bg-slate-100 border-none rounded-xl pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500/50 focus:bg-white transition-all"
              />
            </div>
         </div>
         <div className="flex-1 overflow-y-auto custom-scrollbar pb-4 pt-2">
            {/* Favorites Section */}
            {sortedStarred.length > 0 && (
              <div className="mb-4">
                <div className="px-5 py-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center bg-slate-50/50 border-y border-slate-100/50 mb-1">
                  <Star size={11} className="mr-1.5 text-yellow-500" fill="currentColor" /> Favoritos
                </div>
                {sortedStarred.map(user => (
                  <UserListItem 
                    key={user.id} 
                    user={user} 
                    selectedUserId={selectedUserId}
                    starredUserIds={starredUserIds}
                    unreadCount={currentUser ? getUnreadCount(currentUser.id, user.id) : 0}
                    onSelect={setSelectedUserId}
                    onToggleStar={toggleUserStar}
                  />
                ))}
              </div>
            )}

            {/* Other Contacts Section */}
            {sortedOthers.length > 0 && (
              <div>
                {sortedStarred.length > 0 && (
                   <div className="px-5 py-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider bg-slate-50/50 border-y border-slate-100/50 mb-1">
                     Todos os Contatos
                   </div>
                )}
                {sortedOthers.map(user => (
                  <UserListItem 
                    key={user.id} 
                    user={user} 
                    selectedUserId={selectedUserId}
                    starredUserIds={starredUserIds}
                    unreadCount={currentUser ? getUnreadCount(currentUser.id, user.id) : 0}
                    onSelect={setSelectedUserId}
                    onToggleStar={toggleUserStar}
                  />
                ))}
              </div>
            )}

            {filteredUsers.length === 0 && (
              <div className="p-8 text-center flex flex-col items-center">
                 <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-3">
                   <Search size={20} className="text-slate-400" />
                 </div>
                <p className="text-slate-500 text-sm">Nenhum usuário encontrado.</p>
              </div>
            )}
         </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-slate-50/30 relative">
         {/* Decorative background pattern */}
         <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>

        {selectedUser ? (
          <>
            {/* Header */}
            <div className="px-6 py-4 bg-white/80 backdrop-blur-md border-b border-slate-200 flex justify-between items-center shadow-sm z-10 sticky top-0">
               <div className="flex items-center space-x-4">
                 <div className="relative">
                   <div className={`w-10 h-10 rounded-full overflow-hidden ring-2 ${selectedUser.id === BOT_ID ? 'bg-indigo-100 ring-indigo-200' : 'bg-slate-200 ring-slate-100'}`}>
                     <img src={selectedUser.avatarUrl} alt="" className="w-full h-full object-cover" />
                   </div>
                   {selectedUser.isOnline && (
                     <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                   )}
                 </div>
                 <div>
                   <h3 className="font-bold text-slate-800 flex items-center gap-2 text-lg">
                     {selectedUser.name}
                     {selectedUser.id === BOT_ID && (
                         <span className="bg-indigo-100 text-indigo-700 text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider font-bold">Bot</span>
                     )}
                     <button 
                       onClick={() => toggleUserStar(selectedUser.id)}
                       className="focus:outline-none transition-all active:scale-110 p-1 rounded-full hover:bg-slate-100"
                       title={starredUserIds.includes(selectedUser.id) ? "Remover dos favoritos" : "Adicionar aos favoritos"}
                     >
                        <Star 
                          size={18} 
                          className={starredUserIds.includes(selectedUser.id) ? "text-yellow-400" : "text-slate-300 hover:text-yellow-400"} 
                          fill={starredUserIds.includes(selectedUser.id) ? "currentColor" : "none"}
                        />
                     </button>
                   </h3>
                   <div className="flex items-center text-xs font-medium h-4"> 
                     {/* Fixed height to prevent jump */}
                     {isTyping ? (
                        <span className="text-blue-600 font-semibold italic animate-pulse flex items-center">
                           <span className="w-1 h-1 bg-blue-600 rounded-full mr-1 animate-bounce"></span>
                           digitando...
                        </span>
                     ) : selectedUser.isOnline ? (
                       <span className="text-green-600 flex items-center gap-1 transition-all">
                         <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>Online agora
                       </span>
                     ) : (
                        <span className="text-slate-400">Visto por último recentemente</span>
                     )}
                   </div>
                 </div>
               </div>
               {selectedUser.id !== BOT_ID && (
                   <div className="flex space-x-1 text-slate-400">
                     <button className="p-2.5 hover:bg-slate-100 rounded-xl transition text-slate-500" title="Chamada de voz"><Phone size={20} /></button>
                     <button className="p-2.5 hover:bg-slate-100 rounded-xl transition text-slate-500" title="Videochamada"><Video size={20} /></button>
                     <button className="p-2.5 hover:bg-slate-100 rounded-xl transition text-slate-500"><MoreVertical size={20} /></button>
                   </div>
               )}
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
              {activeChatMessages.map((msg) => {
                const isMe = msg.senderId === currentUser?.id;
                const isBotMessage = msg.senderId === BOT_ID;
                
                return (
                  <div key={msg.id} className={`flex w-full ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className={`flex max-w-[70%] ${isMe ? 'flex-row-reverse' : 'flex-row'} items-end gap-2`}>
                        {!isMe && (
                             <div className="w-6 h-6 rounded-full bg-slate-200 overflow-hidden shrink-0 mb-1">
                                <img src={selectedUser.avatarUrl} alt="" className="w-full h-full object-cover"/>
                             </div>
                        )}
                        <div className={`relative px-5 py-3 shadow-sm ${
                        isMe 
                            ? 'bg-blue-600 text-white rounded-2xl rounded-br-sm' 
                            : isBotMessage 
                                ? 'bg-indigo-50 border border-indigo-100 text-slate-800 rounded-2xl rounded-bl-sm'
                                : 'bg-white border border-slate-200 text-slate-800 rounded-2xl rounded-bl-sm'
                        }`}>
                            {isBotMessage && <Bot size={14} className="text-indigo-500 mb-1" />}
                            <p className="text-[15px] leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                            <div className={`flex items-center justify-end gap-1 mt-1 text-[10px] ${isMe ? 'text-blue-100' : 'text-slate-400'}`}>
                                <span>{format(new Date(msg.timestamp), 'HH:mm')}</span>
                                {isMe && (
                                    msg.read ? <CheckCheck size={12} className="opacity-80" /> : <Check size={12} className="opacity-60" />
                                )}
                            </div>
                        </div>
                    </div>
                  </div>
                );
              })}
              
              {/* Typing Bubble Indicator inside chat flow */}
              {isTyping && (
                  <div className="flex w-full justify-start animate-[fadeIn_0.3s_ease-out]">
                      <div className="flex items-end gap-2">
                           <div className="w-6 h-6 rounded-full bg-slate-200 overflow-hidden shrink-0 mb-1">
                                <img src={selectedUser.avatarUrl} alt="" className="w-full h-full object-cover"/>
                           </div>
                           <div className="bg-slate-100 border border-slate-200 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
                               <div className="flex space-x-1">
                                   <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                                   <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                                   <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                               </div>
                           </div>
                      </div>
                  </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-5 bg-white border-t border-slate-200">
               <form onSubmit={handleSend} className="flex gap-3 items-center">
                 <input
                    type="text"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder={selectedUserId === BOT_ID ? "Responda ao assistente..." : `Mensagem para ${selectedUser.name}...`}
                    className="flex-1 bg-slate-100 border border-transparent rounded-full px-6 py-3.5 focus:bg-white focus:border-blue-300 focus:ring-4 focus:ring-blue-500/10 focus:outline-none transition-all shadow-inner"
                 />
                 <button 
                  type="submit"
                  disabled={!messageText.trim()}
                  className="bg-blue-600 text-white p-3.5 rounded-full hover:bg-blue-700 disabled:opacity-50 disabled:hover:bg-blue-600 transition-all shadow-lg shadow-blue-500/30 hover:shadow-blue-600/40 hover:scale-105 active:scale-95"
                 >
                   <Send size={20} className={messageText.trim() ? "translate-x-0.5" : ""} />
                 </button>
               </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-6 shadow-sm border border-slate-200">
               <MessageSquare size={40} className="text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-700 mb-2">Suas mensagens</h3>
            <p className="text-slate-500 max-w-xs text-center">Selecione um contato da lista para ver o histórico ou iniciar uma nova conversa.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chat;

import React, { useMemo, useState } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip, ResponsiveContainer, 
  PieChart, Pie, Cell
} from 'recharts';
import { useData } from '../context/DataContext';
import { TicketStatus, Role, TicketPriority } from '../types';
import { Clock, CheckCircle, AlertCircle, PlayCircle, TrendingUp, Activity, Server, Zap, Bell, ArrowUpRight, Wifi, Globe, ExternalLink, RefreshCw, AlertTriangle, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { format, subDays, isSameDay, parseISO, startOfDay, differenceInDays } from 'date-fns';
import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const { tickets, users, latency, isOnline, connectionInfo, verificarLatencia } = useData();
  const { user } = useAuth();
  const [isRefreshing, setIsRefreshing] = useState(false);

  // 1. Filter tickets based on permission (Memoized)
  const visibleTickets = useMemo(() => {
    return user?.role === Role.EMPLOYEE 
      ? tickets.filter(t => t.requesterId === user.id)
      : tickets;
  }, [tickets, user]);

  // 2. REAL Stats Calculation - Optimized (Single Pass Reduce)
  const stats = useMemo(() => {
    const today = new Date();
    
    return visibleTickets.reduce((acc, ticket) => {
      // Total count
      acc.total++;

      // Tickets Today
      if (isSameDay(parseISO(ticket.createdAt), today)) {
        acc.ticketsToday++;
      }

      // Status Counts
      if (ticket.status === TicketStatus.OPEN) acc.open++;
      else if (ticket.status === TicketStatus.IN_PROGRESS) acc.inProgress++;
      else if (ticket.status === TicketStatus.RESOLVED || ticket.status === TicketStatus.CLOSED) acc.resolved++;

      // Critical Check
      if (ticket.priority === TicketPriority.CRITICAL && 
          ticket.status !== TicketStatus.RESOLVED && 
          ticket.status !== TicketStatus.CLOSED) {
        acc.critical++;
      }

      return acc;
    }, {
      total: 0,
      ticketsToday: 0,
      open: 0,
      inProgress: 0,
      resolved: 0,
      critical: 0
    });
  }, [visibleTickets]);

  // 3. Trend Data (Last 7 Days) - Optimized (Map-based bucket)
  const trendData = useMemo(() => {
    // Initialize map for last 7 days
    const daysMap = new Map<string, number>();
    const today = startOfDay(new Date());
    
    for (let i = 6; i >= 0; i--) {
      const dateStr = format(subDays(today, i), 'dd/MM');
      daysMap.set(dateStr, 0);
    }

    // Single pass to bucket tickets
    visibleTickets.forEach(t => {
      const tDate = parseISO(t.createdAt);
      // Check if ticket is within the last 7 days window approx
      const diff = differenceInDays(today, tDate);
      if (diff >= 0 && diff <= 6) {
         const dateKey = format(tDate, 'dd/MM');
         if (daysMap.has(dateKey)) {
           daysMap.set(dateKey, (daysMap.get(dateKey) || 0) + 1);
         }
      }
    });

    // Convert map back to array for Recharts
    return Array.from(daysMap.entries()).map(([name, chamados]) => ({ name, chamados }));
  }, [visibleTickets]);

  // 4. Activity Feed - Memoized
  const recentActivity = useMemo(() => {
    // Extract recent comments, optimized sort
    const allActivities = visibleTickets.flatMap(t => 
      t.comments.map(c => ({
        ...c,
        ticketTitle: t.title,
        ticketId: t.id
      }))
    );
    // Sort descending by string comparison (ISO dates work with string compare)
    return allActivities
      .sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1))
      .slice(0, 5);
  }, [visibleTickets]);

  const handleManualRefresh = async () => {
      setIsRefreshing(true);
      await verificarLatencia();
      setTimeout(() => setIsRefreshing(false), 500);
  };

  // Chart Colors & Config
  const COLORS = {
    open: '#3b82f6',
    progress: '#f59e0b',
    resolved: '#10b981',
    critical: '#ef4444'
  };

  const dataStatus = useMemo(() => [
    { name: 'Aberto', value: stats.open, color: COLORS.open },
    { name: 'Em Andamento', value: stats.inProgress, color: COLORS.progress },
    { name: 'Resolvido', value: stats.resolved, color: COLORS.resolved },
  ], [stats]);

  const StatCard = ({ title, value, icon: Icon, color, subtext }: any) => (
    <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition-all duration-300">
      <div className={`absolute top-0 right-0 p-3 opacity-[0.05] group-hover:opacity-10 transition-opacity text-${color}-600`}>
          <Icon size={100} />
      </div>
      <div className="flex justify-between items-start mb-4 relative z-10">
        <div className={`p-2.5 rounded-xl bg-${color}-50 text-${color}-600`}>
           <Icon size={22} />
        </div>
        {subtext && (
           <span className="flex items-center text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
             <ArrowUpRight size={12} className="mr-1" /> {subtext}
           </span>
        )}
      </div>
      <div className="relative z-10">
          <h3 className="text-3xl font-extrabold text-slate-800">{value}</h3>
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mt-1">{title}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-[fadeIn_0.5s_ease-out]">
      
      {/* Header & System Status Bar */}
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between items-end md:items-center">
            <div>
                <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                    <Activity className="text-blue-600" /> Centro de Comando
                </h1>
                <p className="text-slate-500 text-sm mt-1">Monitoramento em tempo real do Service Desk</p>
            </div>
            <div className="flex items-center gap-3">
                 <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-100 rounded-full">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    <span className="text-xs font-bold text-emerald-700">Sistemas Operacionais</span>
                 </div>
                 <div className="text-xs font-medium text-slate-400 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm flex items-center">
                    <Clock size={14} className="mr-2" />
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                 </div>
            </div>
        </div>

        {/* Real-Time System Health Widgets */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            
            {/* Widget 1: System Monitor Link */}
            <a 
               href="https://v2app.siszapp.net.br/index.html" 
               target="_blank" 
               rel="noopener noreferrer"
               className="bg-slate-900 rounded-xl p-4 flex items-center justify-between shadow-lg shadow-slate-900/10 text-white hover:bg-slate-800 transition-colors cursor-pointer group"
            >
                <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider flex items-center gap-1">
                        App SISZ <ExternalLink size={10} />
                    </p>
                    <p className={`text-lg font-mono font-bold ${isOnline ? 'text-emerald-400' : 'text-red-400'}`}>
                        {isOnline ? 'ONLINE' : 'OFFLINE'}
                    </p>
                </div>
                <Globe size={20} className="text-slate-500 group-hover:text-blue-400 transition-colors" />
            </a>

            {/* Widget 2: Real Tickets Today */}
            <div className="bg-white rounded-xl p-4 flex items-center justify-between border border-slate-200 shadow-sm">
                 <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Tickets Hoje</p>
                    <p className="text-lg font-bold text-slate-800">
                        {stats.ticketsToday > 0 ? `+${stats.ticketsToday}` : '0'}
                    </p>
                </div>
                <TrendingUp size={20} className="text-blue-500" />
            </div>

            {/* Widget 3: Real Network Latency (Updated) */}
            <div className="bg-white rounded-xl p-4 flex items-center justify-between border border-slate-200 shadow-sm relative group">
                 <div>
                    <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Latência Rede</p>
                        <button 
                            onClick={handleManualRefresh}
                            className={`p-1 rounded-full hover:bg-slate-100 text-slate-400 hover:text-blue-600 transition-all ${isRefreshing ? 'animate-spin' : ''}`}
                            title="Verificar agora"
                        >
                            <RefreshCw size={10} />
                        </button>
                    </div>
                    <div className="flex items-baseline gap-2">
                        <p className={`text-lg font-mono font-bold ${
                            latency === null ? 'text-slate-400' : 
                            latency < 100 ? 'text-emerald-600' : 
                            latency < 300 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                            {latency !== null ? `${latency}ms` : '--'}
                        </p>
                        {latency !== null && (
                            <span className={`w-2 h-2 rounded-full ${latency < 100 ? 'bg-emerald-500' : latency < 300 ? 'bg-yellow-500' : 'bg-red-500'} animate-pulse`}></span>
                        )}
                    </div>
                </div>
                <Zap size={20} className={latency && latency < 100 ? "text-emerald-500" : "text-yellow-500"} />
            </div>

            {/* Widget 4: Connection Info */}
            <div className="bg-white rounded-xl p-4 flex items-center justify-between border border-slate-200 shadow-sm" title="Estimativa baseada na API do navegador">
                 <div>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Conexão</p>
                    <p className="text-sm font-bold text-slate-700 truncate">
                        {connectionInfo ? `${connectionInfo.downlink} Mbps` : 'Wifi 5Ghz'}
                    </p>
                </div>
                <Wifi size={20} className="text-blue-500" />
            </div>
        </div>
      </div>

      {/* Critical Tickets Hero Card */}
      {stats.critical > 0 && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-red-600 to-rose-600 p-8 shadow-xl shadow-red-500/25 text-white animate-[fadeIn_0.5s_ease-out]">
            {/* Background Effects */}
            <div className="absolute top-0 right-0 -mt-10 -mr-10 w-48 h-48 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-32 h-32 bg-black/10 rounded-full blur-2xl"></div>
            
            <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div className="flex items-center gap-5">
                    <div className="p-4 bg-white/20 backdrop-blur-md rounded-2xl border border-white/20 shadow-inner flex-shrink-0">
                        <ShieldAlert size={40} className="text-white animate-pulse" />
                    </div>
                    <div>
                        <div className="flex items-center gap-2 mb-1">
                             <span className="bg-red-800/40 text-red-50 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border border-red-400/30">Alta Prioridade</span>
                        </div>
                        <h2 className="text-3xl font-bold leading-none mb-1">{stats.critical} Chamados Críticos</h2>
                        <p className="text-red-100 font-medium text-sm md:text-base opacity-90 max-w-md">
                            Existem solicitações que requerem atenção imediata. O tempo de resposta (SLA) pode estar comprometido.
                        </p>
                    </div>
                </div>
                <Link 
                    to="/tickets" 
                    className="group flex items-center gap-3 bg-white text-red-600 px-6 py-4 rounded-xl font-bold shadow-lg hover:bg-red-50 transition-all hover:scale-105 active:scale-95 whitespace-nowrap"
                >
                    <span>Resolver Agora</span>
                    <div className="bg-red-100 p-1 rounded-full group-hover:bg-red-200 transition-colors">
                         <ArrowUpRight size={16} className="text-red-600" />
                    </div>
                </Link>
            </div>
        </div>
      )}

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Chamados" value={stats.total} icon={TrendingUp} color="slate" subtext="Base Total" />
        <StatCard title="Abertos" value={stats.open} icon={AlertCircle} color="blue" />
        <StatCard title="Em Atendimento" value={stats.inProgress} icon={PlayCircle} color="amber" />
        <StatCard title="Concluídos" value={stats.resolved} icon={CheckCircle} color="emerald" subtext="Resolvidos" />
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Charts */}
        <div className="lg:col-span-2 space-y-6">
             {/* Weekly Trend Chart */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2">
                        <TrendingUp size={18} className="text-blue-500" /> Volume Semanal
                    </h3>
                </div>
                <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={trendData}>
                            <defs>
                                <linearGradient id="colorChamados" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#94a3b8'}} dy={10} />
                            <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#94a3b8'}} />
                            <ReTooltip 
                                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                                cursor={{ stroke: '#cbd5e1', strokeWidth: 1, strokeDasharray: '4 4' }}
                            />
                            <Area type="monotone" dataKey="chamados" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorChamados)" />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Split Charts: Priority & Status */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {/* Status Pie */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center justify-center">
                    <h3 className="font-bold text-slate-800 w-full mb-2">Status Atual</h3>
                    <div className="w-full h-48 relative">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={dataStatus}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {dataStatus.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                                    ))}
                                </Pie>
                                <ReTooltip />
                            </PieChart>
                        </ResponsiveContainer>
                        {/* Center Text */}
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                             <div className="text-center">
                                 <span className="block text-2xl font-bold text-slate-800">{stats.open + stats.inProgress}</span>
                                 <span className="text-[10px] text-slate-400 uppercase font-bold">Ativos</span>
                             </div>
                        </div>
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col">
                     <h3 className="font-bold text-slate-800 mb-4">Ações Rápidas</h3>
                     <div className="space-y-3 flex-1">
                        <Link to="/tickets" className="flex items-center justify-between p-3 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors group">
                            <span className="font-medium text-sm">Abrir Novo Chamado</span>
                            <div className="bg-white p-1.5 rounded-lg shadow-sm group-hover:translate-x-1 transition-transform">
                                <ArrowUpRight size={14} />
                            </div>
                        </Link>
                        <Link to="/chat" className="flex items-center justify-between p-3 rounded-xl bg-slate-50 text-slate-700 hover:bg-slate-100 transition-colors group">
                            <span className="font-medium text-sm">Falar com Suporte</span>
                            <div className="bg-white p-1.5 rounded-lg shadow-sm group-hover:translate-x-1 transition-transform">
                                <ArrowUpRight size={14} />
                            </div>
                        </Link>
                         <div className="mt-auto pt-4 border-t border-slate-100">
                             <p className="text-xs text-slate-400 mb-2">Produtividade da Equipe</p>
                             <div className="w-full bg-slate-100 rounded-full h-2">
                                <div className="bg-emerald-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                             </div>
                             <div className="flex justify-between mt-1">
                                <span className="text-[10px] font-bold text-slate-500">85% Meta Semanal</span>
                             </div>
                         </div>
                     </div>
                </div>
            </div>
        </div>

        {/* Right Column: Activity Feed */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 flex flex-col h-full overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                    <Bell size={16} className="text-slate-400" /> Atividade Recente
                </h3>
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            </div>
            
            <div className="flex-1 overflow-y-auto custom-scrollbar p-0">
                {recentActivity.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-sm">Nenhuma atividade recente.</div>
                ) : (
                    recentActivity.map((activity, idx) => {
                        const userWhoActed = users.find(u => u.id === activity.userId);
                        const isSystem = activity.type === 'SYSTEM_LOG';

                        return (
                            <div key={idx} className="p-4 border-b border-slate-50 hover:bg-slate-50/50 transition-colors last:border-0 flex gap-3">
                                <div className="shrink-0 mt-1">
                                    {isSystem ? (
                                        <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500">
                                            <Server size={14} />
                                        </div>
                                    ) : (
                                        <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center overflow-hidden">
                                            <img src={userWhoActed?.avatarUrl} alt="" className="w-full h-full object-cover" />
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <p className="text-xs text-slate-500 mb-0.5">
                                        {format(new Date(activity.createdAt), 'HH:mm')} • <span className="font-semibold text-slate-700">{userWhoActed?.name || 'Sistema'}</span>
                                    </p>
                                    <p className="text-sm font-medium text-slate-800 line-clamp-2">
                                        {activity.content}
                                    </p>
                                    <Link to={`/tickets/${activity.ticketId}`} className="text-[10px] font-bold text-blue-600 hover:underline mt-1 inline-block">
                                        Ref: {activity.ticketTitle}
                                    </Link>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
            <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
                <Link to="/tickets" className="text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors">
                    Ver todo o histórico
                </Link>
            </div>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;

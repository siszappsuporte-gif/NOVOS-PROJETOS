
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { TicketCategory, Article, Role } from '../types';
import { Search, BookOpen, ThumbsUp, Eye, Clock, X, ChevronRight, Hash, Bookmark, Plus, Edit2, Trash2, Save } from 'lucide-react';
import { format } from 'date-fns';

const KnowledgeBase: React.FC = () => {
  const { articles, toggleArticleLike, users, addArticle, updateArticle, deleteArticle } = useData();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  // Editor State
  const [showEditor, setShowEditor] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Partial<Article>>({});

  const canEdit = user?.role === Role.ADMIN || user?.role === Role.TECHNICIAN;
  const categories = ['ALL', ...Object.values(TicketCategory)];

  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          article.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'ALL' || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getAuthorName = (authorId: string) => {
      const user = users.find(u => u.id === authorId);
      return user ? user.name : 'Equipe de Suporte';
  };

  const handleOpenArticle = (article: Article) => {
      setSelectedArticle(article);
  };

  const handleNewArticle = () => {
      setEditingArticle({
          category: TicketCategory.OTHER,
          content: '',
          title: '',
          excerpt: ''
      });
      setShowEditor(true);
  };

  const handleEditArticle = (article: Article, e?: React.MouseEvent) => {
      e?.stopPropagation();
      setEditingArticle({ ...article });
      setShowEditor(true);
      // If opened from modal, close modal
      setSelectedArticle(null);
  };

  const handleDeleteArticle = (id: string, e?: React.MouseEvent) => {
      e?.stopPropagation();
      if (confirm('Tem certeza que deseja excluir este artigo?')) {
          deleteArticle(id);
          setSelectedArticle(null);
      }
  };

  const handleSaveArticle = (e: React.FormEvent) => {
      e.preventDefault();
      if (!editingArticle.title || !editingArticle.content) return;

      if (editingArticle.id) {
          // Update
          updateArticle(editingArticle as Article);
      } else {
          // Create
          const newArticle: Article = {
              id: `kb-${Date.now()}`,
              title: editingArticle.title!,
              content: editingArticle.content!,
              excerpt: editingArticle.excerpt || editingArticle.content!.substring(0, 100) + '...',
              category: editingArticle.category as TicketCategory,
              authorId: user?.id || 'u-bot',
              createdAt: new Date().toISOString(),
              likes: 0,
              views: 0
          };
          addArticle(newArticle);
      }
      setShowEditor(false);
  };

  return (
    <div className="space-y-6 animate-[fadeIn_0.5s_ease-out]">
      
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-8 md:p-12 text-white shadow-xl shadow-blue-500/20 relative overflow-hidden">
         <div className="relative z-10 max-w-2xl">
             <div className="flex items-center gap-3 mb-4 opacity-80">
                 <BookOpen size={24} />
                 <span className="text-sm font-bold uppercase tracking-wider">Centro de Ajuda</span>
             </div>
             <h1 className="text-3xl md:text-5xl font-bold mb-4">Como podemos ajudar?</h1>
             <p className="text-blue-100 text-lg mb-8">Encontre respostas rápidas, tutoriais e soluções para os problemas mais comuns.</p>
             
             <div className="relative">
                 <Search className="absolute left-4 top-4 text-slate-400" size={24} />
                 <input 
                    type="text" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Pesquise por palavras-chave (ex: VPN, senha, impressora)..."
                    className="w-full pl-14 pr-6 py-4 rounded-xl bg-white text-slate-800 placeholder-slate-400 shadow-lg focus:outline-none focus:ring-4 focus:ring-blue-400/30 transition-all text-lg"
                 />
             </div>
         </div>

         {canEdit && (
             <div className="absolute top-8 right-8 z-20">
                 <button 
                    onClick={handleNewArticle}
                    className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition-all"
                 >
                     <Plus size={18} /> Novo Artigo
                 </button>
             </div>
         )}

         {/* Decorative Circles */}
         <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
         <div className="absolute bottom-0 right-20 -mb-10 w-40 h-40 bg-blue-400/20 rounded-full blur-2xl"></div>
      </div>

      {/* Filter Tags */}
      <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
          {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-xl font-medium text-sm transition-all whitespace-nowrap ${
                    selectedCategory === cat 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' 
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                  {cat === 'ALL' ? 'Todos os Artigos' : cat}
              </button>
          ))}
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.length > 0 ? (
             filteredArticles.map(article => (
                <div 
                    key={article.id} 
                    onClick={() => handleOpenArticle(article)}
                    className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer group flex flex-col h-full relative"
                >
                    <div className="flex justify-between items-start mb-4">
                        <span className="px-3 py-1 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold uppercase tracking-wider group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                            {article.category}
                        </span>
                        
                        {canEdit ? (
                             <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                 <button onClick={(e) => handleEditArticle(article, e)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded"><Edit2 size={16} /></button>
                                 <button onClick={(e) => handleDeleteArticle(article.id, e)} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded"><Trash2 size={16} /></button>
                             </div>
                        ) : (
                            <div className="text-slate-300 group-hover:text-blue-500 transition-colors">
                                <Bookmark size={20} />
                            </div>
                        )}
                    </div>
                    
                    <h3 className="text-xl font-bold text-slate-800 mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
                        {article.title}
                    </h3>
                    
                    <p className="text-slate-500 text-sm mb-6 line-clamp-3 flex-1">
                        {article.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-slate-50 text-xs text-slate-400">
                        <div className="flex items-center gap-3">
                            <span className="flex items-center gap-1"><ThumbsUp size={14} /> {article.likes}</span>
                            <span className="flex items-center gap-1"><Eye size={14} /> {article.views}</span>
                        </div>
                        <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform text-blue-500 font-bold">
                            Ler artigo <ChevronRight size={14} />
                        </span>
                    </div>
                </div>
             ))
          ) : (
              <div className="col-span-full py-16 text-center">
                  <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search size={32} className="text-slate-400" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-700">Nenhum artigo encontrado</h3>
                  <p className="text-slate-500 mt-2">Tente buscar por outros termos ou categorias.</p>
              </div>
          )}
      </div>

      {/* Article Reader Modal */}
      {selectedArticle && !showEditor && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-[fadeIn_0.2s_ease-out]">
              <div className="bg-white rounded-3xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-[scaleIn_0.2s_ease-out]">
                  {/* Modal Header */}
                  <div className="bg-slate-50 p-6 border-b border-slate-100 flex justify-between items-start">
                      <div>
                          <div className="flex items-center gap-2 mb-2">
                              <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-700 text-[10px] font-bold uppercase tracking-wider">
                                  {selectedArticle.category}
                              </span>
                              <span className="flex items-center text-slate-400 text-xs">
                                  <Clock size={12} className="mr-1" />
                                  Atualizado em {format(new Date(selectedArticle.createdAt), 'dd MMM yyyy')}
                              </span>
                          </div>
                          <h2 className="text-2xl font-bold text-slate-900 leading-tight">
                              {selectedArticle.title}
                          </h2>
                      </div>
                      <div className="flex items-center gap-2">
                          {canEdit && (
                              <button 
                                onClick={() => handleEditArticle(selectedArticle)}
                                className="p-2 bg-white rounded-full text-blue-600 hover:bg-blue-50 border border-slate-200 shadow-sm"
                                title="Editar"
                              >
                                  <Edit2 size={18} />
                              </button>
                          )}
                          <button 
                            onClick={() => setSelectedArticle(null)}
                            className="p-2 bg-white rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors shadow-sm border border-slate-200"
                          >
                              <X size={20} />
                          </button>
                      </div>
                  </div>

                  {/* Modal Body */}
                  <div className="p-8 overflow-y-auto custom-scrollbar">
                      <div className="prose prose-slate max-w-none">
                          <p className="text-lg text-slate-600 font-medium leading-relaxed mb-6 border-l-4 border-blue-500 pl-4 bg-blue-50/50 py-2 rounded-r-lg">
                              {selectedArticle.excerpt}
                          </p>
                          <div className="whitespace-pre-wrap text-slate-800 leading-7">
                              {selectedArticle.content}
                          </div>
                      </div>
                  </div>

                  {/* Modal Footer */}
                  <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-between items-center">
                      <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-600 text-sm">
                              {getAuthorName(selectedArticle.authorId).charAt(0)}
                          </div>
                          <div>
                              <p className="text-sm font-bold text-slate-700">{getAuthorName(selectedArticle.authorId)}</p>
                              <p className="text-xs text-slate-400">Autor</p>
                          </div>
                      </div>
                      
                      <button 
                        onClick={() => toggleArticleLike(selectedArticle.id)}
                        className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white border border-slate-200 hover:border-blue-300 hover:bg-blue-50 text-slate-600 hover:text-blue-600 transition-all font-medium shadow-sm active:scale-95"
                      >
                          <ThumbsUp size={18} />
                          Isso foi útil ({selectedArticle.likes})
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Editor Modal */}
      {showEditor && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-[fadeIn_0.2s_ease-out]">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                        {editingArticle.id ? <Edit2 size={18}/> : <Plus size={18}/>}
                        {editingArticle.id ? 'Editar Artigo' : 'Novo Artigo'}
                    </h3>
                    <button onClick={() => setShowEditor(false)} className="text-slate-400 hover:text-slate-600">
                        <X size={20} />
                    </button>
                </div>
                <form onSubmit={handleSaveArticle} className="flex-1 overflow-y-auto p-6 space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Título</label>
                        <input 
                            required
                            className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none font-bold text-lg"
                            value={editingArticle.title || ''}
                            onChange={e => setEditingArticle({...editingArticle, title: e.target.value})}
                            placeholder="Título do Artigo"
                        />
                    </div>
                    <div className="grid grid-cols-1 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Categoria</label>
                            <select 
                                className="w-full border border-slate-200 rounded-lg p-2.5 bg-white outline-none"
                                value={editingArticle.category}
                                onChange={e => setEditingArticle({...editingArticle, category: e.target.value as TicketCategory})}
                            >
                                {Object.values(TicketCategory).map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Resumo (Excerpt)</label>
                        <textarea 
                            className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none h-20 resize-none"
                            value={editingArticle.excerpt || ''}
                            onChange={e => setEditingArticle({...editingArticle, excerpt: e.target.value})}
                            placeholder="Um breve resumo que aparecerá no card..."
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Conteúdo Completo</label>
                        <textarea 
                            required
                            className="w-full border border-slate-200 rounded-lg p-3 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none h-64 font-mono text-sm leading-relaxed"
                            value={editingArticle.content || ''}
                            onChange={e => setEditingArticle({...editingArticle, content: e.target.value})}
                            placeholder="Escreva o conteúdo do artigo aqui..."
                        />
                    </div>
                </form>
                <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-2">
                    <button 
                        type="button"
                        onClick={() => setShowEditor(false)}
                        className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={handleSaveArticle}
                        className="px-6 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg font-bold flex items-center gap-2"
                    >
                        <Save size={18} /> Salvar Artigo
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBase;

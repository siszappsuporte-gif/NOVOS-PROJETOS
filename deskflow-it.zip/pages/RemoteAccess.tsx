import React, { useState, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Role, User } from '../types';
import { 
  MonitorSmartphone, Search, Wifi, Power, Monitor, Maximize2, X, Terminal, 
  AlertTriangle, ShieldCheck, Folder, Settings, Globe, Cpu, Minimize2, 
  Square, MoreHorizontal, HardDrive, LogOut
} from 'lucide-react';

// --- VIRTUAL OS CONSTANTS ---
const APPS = {
  TERMINAL: { id: 'terminal', title: 'Prompt de Comando', icon: Terminal, color: 'bg-black' },
  EXPLORER: { id: 'explorer', title: 'Explorador de Arquivos', icon: Folder, color: 'bg-blue-600' },
  SYS_INFO: { id: 'sys_info', title: 'Info do Sistema', icon: Cpu, color: 'bg-emerald-600' },
  SETTINGS: { id: 'settings', title: 'Configurações', icon: Settings, color: 'bg-slate-600' },
};

// --- DRAGGABLE WINDOW COMPONENT ---
const DraggableWindow = ({ 
  id, title, icon: Icon, children, isActive, isMinimized, onClose, onMinimize, onFocus, initialPos 
}: any) => {
  const [pos, setPos] = useState(initialPos || { x: 100, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    onFocus();
    setIsDragging(true);
    dragStart.current = { x: e.clientX - pos.x, y: e.clientY - pos.y };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        setPos({ x: e.clientX - dragStart.current.x, y: e.clientY - dragStart.current.y });
      }
    };
    const handleMouseUp = () => setIsDragging(false);

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  if (isMinimized) return null;

  return (
    <div 
      className={`absolute rounded-lg shadow-2xl overflow-hidden flex flex-col border border-slate-600 bg-slate-900 text-white transition-shadow ${isActive ? 'z-50 shadow-blue-500/20 ring-1 ring-blue-500/50' : 'z-10'}`}
      style={{ left: pos.x, top: pos.y, width: 600, height: 400 }}
      onMouseDown={onFocus}
    >
      {/* Title Bar */}
      <div 
        className="h-9 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-3 cursor-grab active:cursor-grabbing select-none"
        onMouseDown={handleMouseDown}
      >
        <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
          <Icon size={14} />
          {title}
        </div>
        <div className="flex items-center gap-1">
          <button onClick={(e) => { e.stopPropagation(); onMinimize(); }} className="p-1 hover:bg-slate-700 rounded"><Minimize2 size={12} /></button>
          <button className="p-1 hover:bg-slate-700 rounded"><Square size={12} /></button>
          <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="p-1 hover:bg-red-600 rounded"><X size={12} /></button>
        </div>
      </div>
      {/* Content */}
      <div className="flex-1 overflow-auto relative bg-slate-900/95">
        {children}
      </div>
    </div>
  );
};

// --- TERMINAL APP ---
const TerminalApp = ({ user }: { user: User }) => {
  const [history, setHistory] = useState([
    `Microsoft Windows [versão 10.0.19045.2965]`,
    `(c) Microsoft Corporation. Todos os direitos reservados.`,
    ``,
    `C:\\Users\\${user.name.split(' ')[0]}>`
  ]);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [history]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = input.trim().toLowerCase();
    const newLines = [`${input}`];

    switch (cmd) {
      case 'help':
        newLines.push(`Comandos disponíveis: ping, ipconfig, cls, whoami, exit`);
        break;
      case 'ping':
      case 'ping google.com':
        newLines.push(`Disparando google.com [142.250.218.14] com 32 bytes de dados:`);
        newLines.push(`Resposta de 142.250.218.14: bytes=32 tempo=14ms TTL=116`);
        newLines.push(`Resposta de 142.250.218.14: bytes=32 tempo=15ms TTL=116`);
        break;
      case 'ipconfig':
        newLines.push(`Adaptador Ethernet Ethernet:`);
        newLines.push(`   Sufixo DNS específico de conexão. . . : siszapp.net`);
        newLines.push(`   Endereço IPv4. . . . . . . .  . . . . : 192.168.15.112`);
        newLines.push(`   Máscara de Sub-rede . . . . . . . . . : 255.255.255.0`);
        newLines.push(`   Gateway Padrão. . . . . . . . . . . . : 192.168.15.1`);
        break;
      case 'whoami':
        newLines.push(`company\\${user.name.toLowerCase().replace(' ', '.')}`);
        break;
      case 'cls':
        setHistory([`C:\\Users\\${user.name.split(' ')[0]}>`]);
        setInput('');
        return;
      case 'exit':
        newLines.push('Sessão encerrada.');
        break;
      default:
        if (cmd) newLines.push(`'${cmd}' não é reconhecido como um comando interno.`);
    }

    newLines.push(``);
    newLines.push(`C:\\Users\\${user.name.split(' ')[0]}>`);
    
    setHistory(prev => [...prev.slice(0, -1), `C:\\Users\\${user.name.split(' ')[0]}> ${input}`, ...newLines]);
    setInput('');
  };

  return (
    <div className="p-2 font-mono text-sm text-slate-300 h-full" onClick={() => document.getElementById('term-input')?.focus()}>
      {history.map((line, i) => (
        <div key={i} className="whitespace-pre-wrap">{line}</div>
      ))}
      <form onSubmit={handleCommand} className="flex opacity-0 h-0 overflow-hidden">
        <input 
          id="term-input" 
          type="text" 
          value={input} 
          onChange={e => setInput(e.target.value)} 
          autoFocus 
          autoComplete="off"
        />
      </form>
      <div className="animate-pulse inline-block w-2 h-4 bg-slate-300 align-middle ml-1"></div>
      <div ref={bottomRef} />
    </div>
  );
};

// --- FILE EXPLORER APP ---
const ExplorerApp = () => (
  <div className="flex flex-col h-full bg-slate-50 text-slate-800">
    <div className="flex items-center gap-2 p-2 border-b border-slate-200 bg-white">
      <div className="flex gap-2 text-slate-400">
        <div className="w-6 h-6 rounded hover:bg-slate-100 flex items-center justify-center">←</div>
        <div className="w-6 h-6 rounded hover:bg-slate-100 flex items-center justify-center">→</div>
        <div className="w-6 h-6 rounded hover:bg-slate-100 flex items-center justify-center">↑</div>
      </div>
      <div className="flex-1 bg-slate-100 border border-slate-200 px-3 py-1 text-xs rounded">
        Este Computador {'>'} Documentos
      </div>
    </div>
    <div className="flex flex-1">
      <div className="w-40 border-r border-slate-200 bg-white p-2 text-xs space-y-1">
         <div className="font-bold flex items-center gap-2 p-1 bg-blue-50 text-blue-700 rounded"><HardDrive size={14}/> Este Computador</div>
         <div className="pl-6 p-1 hover:bg-slate-100 rounded cursor-pointer">Área de Trabalho</div>
         <div className="pl-6 p-1 hover:bg-slate-100 rounded cursor-pointer">Downloads</div>
         <div className="pl-6 p-1 hover:bg-slate-100 rounded cursor-pointer">Documentos</div>
         <div className="pl-6 p-1 hover:bg-slate-100 rounded cursor-pointer">Imagens</div>
      </div>
      <div className="flex-1 p-4 grid grid-cols-4 grid-rows-4 gap-4 content-start">
         {['Relatório_Anual.pdf', 'Backup_Logs.log', 'Projeto_X.docx', 'Notas.txt'].map((file, i) => (
           <div key={i} className="flex flex-col items-center gap-1 group cursor-pointer p-2 hover:bg-blue-50 border border-transparent hover:border-blue-200 rounded">
              <div className="w-10 h-10 bg-blue-100 text-blue-500 flex items-center justify-center rounded-lg">
                <Folder size={24} />
              </div>
              <span className="text-xs text-center break-all">{file}</span>
           </div>
         ))}
      </div>
    </div>
    <div className="h-6 bg-white border-t border-slate-200 flex items-center px-2 text-[10px] text-slate-500 gap-4">
        <span>4 itens</span>
        <span>1 item selecionado 24KB</span>
    </div>
  </div>
);

// --- MAIN REMOTE VIEW ---
const RemoteAccess: React.FC = () => {
  const { users } = useData();
  const { user: currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSessionUser, setActiveSessionUser] = useState<User | null>(null);
  const [connectionStep, setConnectionStep] = useState<number>(0); 
  
  // Fake OS State
  const [windows, setWindows] = useState<any[]>([]);
  const [activeWindowId, setActiveWindowId] = useState<string | null>(null);
  const [startMenuOpen, setStartMenuOpen] = useState(false);

  // Auth Check
  if (!currentUser || (currentUser.role !== Role.ADMIN && currentUser.role !== Role.TECHNICIAN)) {
     return (
        <div className="flex flex-col items-center justify-center h-[50vh] text-center">
            <ShieldCheck size={48} className="text-red-500 mb-4" />
            <h2 className="text-2xl font-bold text-slate-800">Acesso Restrito</h2>
            <p className="text-slate-500">Você não tem permissão para acessar o módulo de suporte remoto.</p>
        </div>
     );
  }

  const filteredUsers = users.filter(u => 
    u.id !== currentUser.id && 
    (u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     u.department.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const startConnection = (targetUser: User) => {
    setActiveSessionUser(targetUser);
    setConnectionStep(1);
    setWindows([]); 
    
    setTimeout(() => {
        setConnectionStep(2);
        // Auto open a terminal on connect
        openWindow(APPS.TERMINAL);
    }, 1500);
  };

  const endConnection = () => {
    setActiveSessionUser(null);
    setConnectionStep(0);
    setWindows([]);
  };

  const openWindow = (app: any) => {
    const id = `${app.id}-${Date.now()}`;
    setWindows(prev => [...prev, { ...app, instanceId: id, isMinimized: false, x: 100 + (prev.length * 30), y: 100 + (prev.length * 30) }]);
    setActiveWindowId(id);
    setStartMenuOpen(false);
  };

  const closeWindow = (id: string) => {
    setWindows(prev => prev.filter(w => w.instanceId !== id));
  };

  const toggleMinimize = (id: string) => {
    setWindows(prev => prev.map(w => w.instanceId === id ? { ...w, isMinimized: !w.isMinimized } : w));
  };

  const focusWindow = (id: string) => {
    setActiveWindowId(id);
    // Move to end of array to render on top
    setWindows(prev => {
        const win = prev.find(w => w.instanceId === id);
        if (!win) return prev;
        return [...prev.filter(w => w.instanceId !== id), win];
    });
  };

  // --- RENDER REMOTE DESKTOP ---
  const renderDesktop = () => {
    if (!activeSessionUser) return null;

    if (connectionStep === 1) {
        return (
            <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center font-mono text-green-500">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin"></div>
                    <div className="text-center space-y-2">
                         <p>Estabelecendo túnel seguro com {activeSessionUser.name}...</p>
                         <p className="text-xs text-green-700">Negociando chaves TLS 1.3 | AES-256-GCM</p>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 z-50 bg-black flex flex-col animate-[fadeIn_0.5s_ease-out]">
            {/* Toolbar DeskFlow */}
            <div className="h-10 bg-slate-900 flex items-center justify-between px-4 border-b border-slate-700 shadow-lg shrink-0 z-50">
                <div className="flex items-center gap-3 text-slate-200">
                     <div className="flex items-center gap-2 bg-slate-800 px-3 py-1 rounded-full text-xs font-mono border border-slate-700">
                        <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                        Sessão Ativa: {activeSessionUser.name}
                     </div>
                </div>
                <button 
                    onClick={endConnection}
                    className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs font-bold transition flex items-center gap-1"
                >
                    <X size={14} /> Desconectar
                </button>
            </div>

            {/* Desktop Area */}
            <div className="flex-1 relative overflow-hidden bg-slate-800 select-none group cursor-default">
                 {/* Wallpaper */}
                 <img 
                    src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?q=80&w=2072&auto=format&fit=crop" 
                    alt="Wallpaper"
                    className="absolute inset-0 w-full h-full object-cover opacity-50 pointer-events-none"
                 />
                 
                 {/* Desktop Icons */}
                 <div className="absolute top-4 left-4 flex flex-col gap-6 z-0">
                    {Object.values(APPS).map((app) => (
                        <div 
                            key={app.id} 
                            onDoubleClick={() => openWindow(app)}
                            className="flex flex-col items-center gap-1 w-20 p-2 rounded hover:bg-white/10 cursor-pointer transition-colors border border-transparent hover:border-white/20"
                        >
                            <div className={`w-12 h-12 ${app.color} rounded-xl flex items-center justify-center shadow-lg text-white`}>
                                <app.icon size={24} />
                            </div>
                            <span className="text-white text-xs drop-shadow-md text-center font-medium leading-tight">{app.title}</span>
                        </div>
                    ))}
                 </div>

                 {/* Windows Layer */}
                 {windows.map((win) => (
                    <DraggableWindow 
                        key={win.instanceId}
                        id={win.instanceId}
                        title={win.title}
                        icon={win.icon}
                        initialPos={{ x: win.x, y: win.y }}
                        isActive={activeWindowId === win.instanceId}
                        isMinimized={win.isMinimized}
                        onClose={() => closeWindow(win.instanceId)}
                        onMinimize={() => toggleMinimize(win.instanceId)}
                        onFocus={() => focusWindow(win.instanceId)}
                    >
                        {win.id === 'terminal' && <TerminalApp user={activeSessionUser} />}
                        {win.id === 'explorer' && <ExplorerApp />}
                        {win.id === 'sys_info' && (
                            <div className="p-6 text-slate-300 space-y-4 font-mono text-sm">
                                <h3 className="text-white font-bold border-b border-slate-600 pb-2 mb-4">Informações do Sistema</h3>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="text-slate-500">Hostname:</div><div>DESKTOP-{activeSessionUser.id.toUpperCase().slice(0,5)}</div>
                                    <div className="text-slate-500">OS:</div><div>Windows 11 Enterprise 22H2</div>
                                    <div className="text-slate-500">CPU:</div><div>Intel Core i7-12700H @ 2.30GHz</div>
                                    <div className="text-slate-500">RAM:</div><div>16.0 GB (15.7 GB utilizável)</div>
                                    <div className="text-slate-500">Uptime:</div><div>4d 12h 32m</div>
                                </div>
                            </div>
                        )}
                        {win.id === 'settings' && (
                            <div className="flex items-center justify-center h-full text-slate-500">
                                <Settings size={48} className="animate-spin-slow opacity-20" />
                            </div>
                        )}
                    </DraggableWindow>
                 ))}

                 {/* Start Menu */}
                 {startMenuOpen && (
                    <div className="absolute bottom-12 left-4 w-72 bg-slate-900/95 backdrop-blur-md border border-slate-700 rounded-lg shadow-2xl p-4 z-50 flex flex-col gap-2 animate-[slideInUp_0.2s_ease-out] origin-bottom-left">
                        <div className="flex items-center gap-3 pb-3 border-b border-slate-700 mb-2">
                             <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center text-white font-bold">
                                {activeSessionUser.name.charAt(0)}
                             </div>
                             <div>
                                 <div className="text-sm font-bold text-white">{activeSessionUser.name}</div>
                                 <div className="text-xs text-slate-400">Colaborador</div>
                             </div>
                        </div>
                        {Object.values(APPS).map(app => (
                            <button 
                                key={app.id} 
                                onClick={() => openWindow(app)}
                                className="flex items-center gap-3 p-2 hover:bg-white/10 rounded text-slate-200 text-sm transition-colors text-left"
                            >
                                <div className={`p-1.5 rounded ${app.color}`}><app.icon size={16}/></div>
                                {app.title}
                            </button>
                        ))}
                        <button onClick={endConnection} className="flex items-center gap-3 p-2 hover:bg-red-900/50 rounded text-red-400 text-sm transition-colors mt-2 border-t border-slate-700 pt-3">
                             <LogOut size={16} /> Desconectar / Logoff
                        </button>
                    </div>
                 )}

                 {/* Taskbar */}
                 <div className="absolute bottom-0 left-0 right-0 h-12 bg-slate-900/90 backdrop-blur-md border-t border-white/10 flex items-center px-4 justify-between z-50">
                      <div className="flex items-center gap-2">
                          <button 
                            onClick={() => setStartMenuOpen(!startMenuOpen)}
                            className={`p-2 rounded hover:bg-white/10 transition-colors ${startMenuOpen ? 'bg-white/20' : ''}`}
                          >
                             <div className="grid grid-cols-2 gap-0.5">
                                 <div className="w-2 h-2 bg-blue-500 rounded-sm"></div>
                                 <div className="w-2 h-2 bg-blue-500 rounded-sm"></div>
                                 <div className="w-2 h-2 bg-blue-500 rounded-sm"></div>
                                 <div className="w-2 h-2 bg-blue-500 rounded-sm"></div>
                             </div>
                          </button>
                          
                          <div className="w-px h-6 bg-white/10 mx-2"></div>
                          
                          {/* Search Dummy */}
                          <div className="flex items-center bg-white/5 px-3 py-1.5 rounded-full border border-white/5 w-48">
                              <Search size={14} className="text-slate-400 mr-2" />
                              <span className="text-xs text-slate-500">Pesquisar...</span>
                          </div>

                          {/* Active Windows */}
                          <div className="flex items-center gap-1 ml-4">
                              {windows.map(win => (
                                  <button
                                    key={win.instanceId}
                                    onClick={() => {
                                        if (activeWindowId === win.instanceId && !win.isMinimized) {
                                            toggleMinimize(win.instanceId);
                                        } else {
                                            if (win.isMinimized) toggleMinimize(win.instanceId);
                                            focusWindow(win.instanceId);
                                        }
                                    }}
                                    className={`w-10 h-10 flex items-center justify-center rounded hover:bg-white/10 transition-all relative ${activeWindowId === win.instanceId && !win.isMinimized ? 'bg-white/10' : ''}`}
                                  >
                                      <win.icon size={20} className={win.isMinimized ? 'opacity-50' : 'text-blue-400'} />
                                      {!win.isMinimized && <div className="absolute bottom-0 left-2 right-2 h-0.5 bg-blue-500 rounded-full"></div>}
                                  </button>
                              ))}
                          </div>
                      </div>
                      
                      {/* Tray */}
                      <div className="flex items-center gap-4 text-xs text-slate-300">
                          <Wifi size={16} />
                          <div className="text-right">
                              <div>{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                              <div className="text-[10px] text-slate-500">{new Date().toLocaleDateString()}</div>
                          </div>
                      </div>
                 </div>
            </div>
        </div>
    );
  };

  return (
    <div className="space-y-6 animate-[fadeIn_0.5s_ease-out]">
      {renderDesktop()}

      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
           <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-3">
             <MonitorSmartphone className="text-blue-600" /> Acesso Remoto
           </h1>
           <p className="text-slate-500 font-medium mt-1">Gerencie e acesse estações de trabalho em tempo real.</p>
        </div>
        <div className="flex items-center gap-3">
             <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-100 rounded-full">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                <span className="text-xs font-bold text-green-700">Gateway Seguro Ativo</span>
             </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-4 top-3 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="Buscar colaborador ou hostname..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/50 bg-slate-50 focus:bg-white transition-all"
          />
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
         {filteredUsers.map(u => (
            <div key={u.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-shadow group relative">
                <div className={`h-1.5 w-full ${u.isOnline ? 'bg-green-500' : 'bg-slate-300'}`}></div>
                <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                        <div className="relative">
                            <img src={u.avatarUrl} alt={u.name} className="w-14 h-14 rounded-xl bg-slate-100 object-cover ring-4 ring-slate-50" />
                            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${u.isOnline ? 'bg-green-500' : 'bg-slate-300'}`}></div>
                        </div>
                        {u.isOnline ? (
                            <Wifi size={18} className="text-green-500" />
                        ) : (
                            <Wifi size={18} className="text-slate-300" />
                        )}
                    </div>
                    
                    <h3 className="font-bold text-slate-800 text-lg truncate">{u.name}</h3>
                    <p className="text-sm text-slate-500 mb-4">{u.department}</p>
                    
                    <div className="flex flex-col gap-2 text-xs text-slate-400 bg-slate-50 p-3 rounded-lg border border-slate-100 mb-4">
                        <div className="flex justify-between">
                            <span>Hostname:</span>
                            <span className="font-mono text-slate-600">DESKTOP-{u.id.toUpperCase().slice(0,4)}</span>
                        </div>
                        <div className="flex justify-between">
                            <span>OS:</span>
                            <span className="font-mono text-slate-600">Windows 11 Pro</span>
                        </div>
                    </div>

                    <button
                        onClick={() => startConnection(u)}
                        disabled={!u.isOnline}
                        className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                            u.isOnline 
                                ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-500/30' 
                                : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                        }`}
                    >
                        {u.isOnline ? (
                            <>
                                <MonitorSmartphone size={18} />
                                Conectar
                            </>
                        ) : (
                            <>
                                <Power size={18} />
                                Offline
                            </>
                        )}
                    </button>
                </div>
            </div>
         ))}
      </div>
      
      {filteredUsers.length === 0 && (
         <div className="text-center py-12 text-slate-400">
             <Search size={48} className="mx-auto mb-4 opacity-20" />
             <p>Nenhum usuário encontrado com os filtros atuais.</p>
         </div>
      )}
    </div>
  );
};

export default RemoteAccess;
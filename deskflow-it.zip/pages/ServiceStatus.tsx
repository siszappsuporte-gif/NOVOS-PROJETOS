
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { ServiceHealth, ServiceHealthStatus, Role } from '../types';
import { Activity, CheckCircle, AlertTriangle, XCircle, Wrench, RefreshCcw, Plus, Trash2, X } from 'lucide-react';

const ServiceStatus: React.FC = () => {
  const { services, addService, deleteService } = useData();
  const { user } = useAuth();
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [newService, setNewService] = useState<Partial<ServiceHealth>>({
      status: ServiceHealthStatus.OPERATIONAL,
      uptime: 100
  });

  const canEdit = user?.role === Role.ADMIN || user?.role === Role.TECHNICIAN;

  const handleAddService = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newService.name || !newService.description) return;

      const service: ServiceHealth = {
          id: `srv-${Date.now()}`,
          name: newService.name,
          description: newService.description,
          status: newService.status as ServiceHealthStatus,
          uptime: newService.uptime || 100,
          lastIncident: newService.lastIncident
      };

      addService(service);
      setShowAddModal(false);
      setNewService({ status: ServiceHealthStatus.OPERATIONAL, uptime: 100 });
  };

  const getStatusIcon = (status: ServiceHealthStatus) => {
    switch(status) {
        case ServiceHealthStatus.OPERATIONAL: return <CheckCircle className="text-emerald-500" size={24} />;
        case ServiceHealthStatus.DEGRADED: return <AlertTriangle className="text-yellow-500" size={24} />;
        case ServiceHealthStatus.OUTAGE: return <XCircle className="text-red-500" size={24} />;
        case ServiceHealthStatus.MAINTENANCE: return <Wrench className="text-blue-500" size={24} />;
    }
  };

  const getStatusLabel = (status: ServiceHealthStatus) => {
    switch(status) {
        case ServiceHealthStatus.OPERATIONAL: return 'Operacional';
        case ServiceHealthStatus.DEGRADED: return 'Lentidão / Instável';
        case ServiceHealthStatus.OUTAGE: return 'Fora do Ar';
        case ServiceHealthStatus.MAINTENANCE: return 'Em Manutenção';
    }
  };

  const getStatusBg = (status: ServiceHealthStatus) => {
    switch(status) {
        case ServiceHealthStatus.OPERATIONAL: return 'bg-emerald-50 border-emerald-100';
        case ServiceHealthStatus.DEGRADED: return 'bg-yellow-50 border-yellow-100';
        case ServiceHealthStatus.OUTAGE: return 'bg-red-50 border-red-100';
        case ServiceHealthStatus.MAINTENANCE: return 'bg-blue-50 border-blue-100';
    }
  };

  return (
    <div className="space-y-6 animate-[fadeIn_0.5s_ease-out] max-w-4xl mx-auto">
         <div className="text-center py-8 relative">
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center justify-center gap-3">
               <Activity className="text-blue-600" /> Status dos Serviços
            </h1>
            <p className="text-slate-500 font-medium mt-2">Monitoramento em tempo real da infraestrutura.</p>
            <div className="mt-4 text-xs text-slate-400 flex items-center justify-center gap-2">
                <RefreshCcw size={12} className="animate-spin-slow" />
                Atualizado em {new Date().toLocaleTimeString()}
            </div>
            
            {canEdit && (
                <div className="absolute right-0 top-1/2 -translate-y-1/2 hidden md:block">
                     <button 
                        onClick={() => setShowAddModal(true)}
                        className="bg-slate-900 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-slate-800 transition"
                     >
                         <Plus size={16} /> Add Serviço
                     </button>
                </div>
            )}
         </div>
         
         {/* Mobile Add Button */}
         {canEdit && (
             <div className="md:hidden flex justify-center mb-4">
                 <button 
                    onClick={() => setShowAddModal(true)}
                    className="bg-slate-900 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 w-full justify-center"
                 >
                     <Plus size={16} /> Adicionar Serviço
                 </button>
             </div>
         )}

         <div className="grid gap-4">
             {services.map(service => (
                 <div key={service.id} className={`p-6 rounded-2xl border ${getStatusBg(service.status)} shadow-sm transition-all hover:shadow-md bg-white relative group`}>
                     
                     {canEdit && (
                         <button 
                            onClick={() => deleteService(service.id)}
                            className="absolute top-4 right-4 p-2 bg-white/50 hover:bg-red-100 text-slate-400 hover:text-red-600 rounded-full transition opacity-0 group-hover:opacity-100"
                            title="Remover Serviço"
                         >
                             <Trash2 size={16} />
                         </button>
                     )}

                     <div className="flex items-start justify-between pr-8">
                         <div className="flex gap-4">
                             <div className="mt-1">{getStatusIcon(service.status)}</div>
                             <div>
                                 <h3 className="text-lg font-bold text-slate-800">{service.name}</h3>
                                 <p className="text-slate-500 text-sm mb-2">{service.description}</p>
                                 
                                 {service.lastIncident && (
                                     <div className="mt-3 p-3 bg-white/60 rounded-lg border border-slate-200/50 text-sm">
                                         <span className="font-bold text-slate-700">Último Incidente:</span> <span className="text-slate-600">{service.lastIncident}</span>
                                     </div>
                                 )}
                             </div>
                         </div>
                         <div className="text-right hidden sm:block">
                             <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold border mb-2 ${
                                 service.status === ServiceHealthStatus.OPERATIONAL ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                                 service.status === ServiceHealthStatus.DEGRADED ? 'bg-yellow-100 text-yellow-700 border-yellow-200' :
                                 service.status === ServiceHealthStatus.OUTAGE ? 'bg-red-100 text-red-700 border-red-200' :
                                 'bg-blue-100 text-blue-700 border-blue-200'
                             }`}>
                                 {getStatusLabel(service.status)}
                             </div>
                             <div className="text-xs font-mono text-slate-400">
                                 Uptime: <span className="font-bold text-slate-600">{service.uptime}%</span>
                             </div>
                         </div>
                     </div>
                     
                     {/* Fake Timeline Bar */}
                     <div className="mt-6 flex gap-1 h-2 w-full">
                         {[...Array(30)].map((_, i) => {
                             let color = 'bg-emerald-400';
                             if (service.status !== ServiceHealthStatus.OPERATIONAL && i > 25) {
                                  color = service.status === ServiceHealthStatus.DEGRADED ? 'bg-yellow-400' : 
                                          service.status === ServiceHealthStatus.OUTAGE ? 'bg-red-400' : 'bg-blue-400';
                             }
                             if (service.uptime < 99 && i === 15) color = 'bg-yellow-400';

                             return (
                                 <div key={i} className={`flex-1 rounded-full ${color} opacity-80`} title={`Dia ${i+1}: Operacional`}></div>
                             )
                         })}
                     </div>
                     <div className="flex justify-between text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-bold">
                         <span>30 dias atrás</span>
                         <span>Hoje</span>
                     </div>
                 </div>
             ))}
         </div>

         {/* Add Modal */}
         {showAddModal && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden animate-[scaleIn_0.2s_ease-out]">
                    <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                        <h3 className="font-bold text-lg text-slate-800">Adicionar Serviço</h3>
                        <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                            <X size={20} />
                        </button>
                    </div>
                    <form onSubmit={handleAddService} className="p-6 space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome do Serviço</label>
                            <input 
                                required
                                className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                value={newService.name || ''}
                                onChange={e => setNewService({...newService, name: e.target.value})}
                                placeholder="Ex: Servidor de Email"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status Atual</label>
                            <select 
                                className="w-full border border-slate-200 rounded-lg p-2.5 bg-white outline-none"
                                value={newService.status}
                                onChange={e => setNewService({...newService, status: e.target.value as ServiceHealthStatus})}
                            >
                                {Object.values(ServiceHealthStatus).map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Descrição</label>
                            <input 
                                required
                                className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                value={newService.description || ''}
                                onChange={e => setNewService({...newService, description: e.target.value})}
                                placeholder="Breve descrição da função do serviço"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Último Incidente (Opcional)</label>
                            <input 
                                className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                                value={newService.lastIncident || ''}
                                onChange={e => setNewService({...newService, lastIncident: e.target.value})}
                                placeholder="Ex: Lentidão detectada às 14h"
                            />
                        </div>
                        <div className="pt-4 flex justify-end gap-2">
                            <button 
                                type="button"
                                onClick={() => setShowAddModal(false)}
                                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                            >
                                Cancelar
                            </button>
                            <button 
                                type="submit"
                                className="px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg font-bold"
                            >
                                Salvar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        )}
    </div>
  );
};

export default ServiceStatus;

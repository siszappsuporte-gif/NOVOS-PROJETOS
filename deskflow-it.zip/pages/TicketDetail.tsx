
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { TicketStatus, Role } from '../types';
import { StatusBadge, PriorityBadge } from '../components/StatusBadge';
import { format } from 'date-fns';
import { Send, ArrowLeft, Clock, User as UserIcon, Paperclip, CheckCircle2, ChevronDown, Archive, AlertCircle, Tag, Flag } from 'lucide-react';

const TicketDetail: React.FC = () => {
  const { ticketId } = useParams<{ ticketId: string }>();
  const navigate = useNavigate();
  const { tickets, updateTicketStatus, assignTicket, addComment, users } = useData();
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [commentText, setCommentText] = useState('');
  
  const ticket = tickets.find(t => t.id === ticketId);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [ticket?.comments]);

  if (!ticket || !user) return <div className="p-8 text-center text-slate-500">Carregando chamado...</div>;

  const canManage = user.role === Role.ADMIN || user.role === Role.TECHNICIAN;
  const requester = users.find(u => u.id === ticket.requesterId);
  const assignee = users.find(u => u.id === ticket.assigneeId);

  // List of potential assignees (Technicians and Admins)
  const technicalUsers = users.filter(u => u.role === Role.TECHNICIAN || u.role === Role.ADMIN);

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      addComment(ticket.id, commentText, user.id);
      setCommentText('');
    }
  };

  const handleStatusChange = (newStatus: TicketStatus) => {
    updateTicketStatus(ticket.id, newStatus, user.id);
  };

  const handleAssigneeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newAssigneeId = e.target.value === "UNASSIGNED" ? null : e.target.value;
    assignTicket(ticket.id, newAssigneeId, user.id);
  };

  const STATUS_LABELS: Record<string, string> = {
    [TicketStatus.OPEN]: 'Aberto',
    [TicketStatus.IN_PROGRESS]: 'Em Andamento',
    [TicketStatus.WAITING_USER]: 'Aguardando Usuário',
    [TicketStatus.RESOLVED]: 'Resolvido',
    [TicketStatus.CLOSED]: 'Encerrado',
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-[fadeIn_0.5s_ease-out] pb-10">
      <button onClick={() => navigate('/tickets')} className="flex items-center text-slate-500 hover:text-slate-900 transition-colors font-medium">
        <ArrowLeft size={18} className="mr-2" /> Voltar para Chamados
      </button>

      {/* 1. TOP CARD: Meta Info & Controls */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Header Section */}
        <div className="p-6 md:p-8 border-b border-slate-100">
           <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                 <div className="flex items-center gap-3 mb-2">
                    <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-xs font-mono font-bold border border-slate-200">{ticket.id}</span>
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                        <Clock size={12} /> Criado em {format(new Date(ticket.createdAt), 'dd MMM yyyy, HH:mm')}
                    </span>
                 </div>
                 <h1 className="text-2xl md:text-3xl font-bold text-slate-900 leading-tight">{ticket.title}</h1>
              </div>
              <div className="shrink-0">
                 <StatusBadge status={ticket.status} />
              </div>
           </div>

           {/* Quick Stats Bar */}
           <div className="bg-slate-50 rounded-xl border border-slate-100 p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Priority */}
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1"><Flag size={10} /> Prioridade</span>
                    <div><PriorityBadge priority={ticket.priority} /></div>
                </div>

                {/* Category */}
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1"><Tag size={10} /> Categoria</span>
                    <span className="text-sm font-semibold text-slate-700">{ticket.category}</span>
                </div>

                {/* Requester */}
                <div className="flex flex-col">
                     <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1"><UserIcon size={10} /> Solicitante</span>
                     <div className="flex items-center gap-2">
                        <div className="w-5 h-5 rounded-full bg-slate-200 overflow-hidden">
                             <img src={requester?.avatarUrl || `https://ui-avatars.com/api/?name=${requester?.name}`} className="w-full h-full object-cover" />
                        </div>
                        <span className="text-sm font-semibold text-slate-700 truncate">{requester?.name || 'Desconhecido'}</span>
                     </div>
                </div>

                {/* Assignee */}
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1"><CheckCircle2 size={10} /> Responsável</span>
                    {canManage ? (
                       <div className="relative group max-w-[200px]">
                         <select
                            value={ticket.assigneeId || "UNASSIGNED"}
                            onChange={handleAssigneeChange}
                            className="w-full pl-2 pr-6 py-0.5 bg-transparent border-b border-slate-300 focus:border-blue-500 appearance-none focus:outline-none cursor-pointer text-sm font-bold text-slate-700 hover:text-blue-600 transition-colors"
                         >
                            <option value="UNASSIGNED">? Não atribuído</option>
                            {technicalUsers.map(u => (
                                <option key={u.id} value={u.id}>{u.name}</option>
                            ))}
                         </select>
                         <ChevronDown size={14} className="absolute right-0 top-1 text-slate-400 pointer-events-none" />
                       </div>
                    ) : (
                        <div className="flex items-center gap-2">
                             {assignee ? (
                                <>
                                    <div className="w-5 h-5 rounded-full bg-slate-200 overflow-hidden">
                                        <img src={assignee.avatarUrl} className="w-full h-full object-cover" />
                                    </div>
                                    <span className="text-sm font-semibold text-slate-700">{assignee.name}</span>
                                </>
                             ) : (
                                <span className="text-sm text-slate-400 italic">Não atribuído</span>
                             )}
                        </div>
                    )}
                </div>
           </div>

           {/* Description Body */}
           <div className="mt-6">
                <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">Descrição do Problema</h3>
                <div className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                    {ticket.description}
                </div>
           </div>
        </div>

        {/* Action Bar (Admins Only) */}
        {canManage && (
            <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex flex-wrap gap-2 items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase hidden md:inline-block">Ações de Status:</span>
                <div className="flex gap-2 overflow-x-auto pb-1 md:pb-0 w-full md:w-auto">
                    {Object.values(TicketStatus).map((status) => {
                        if (status === TicketStatus.CLOSED && ticket.status !== TicketStatus.RESOLVED) return null; // Only show close if resolved
                        
                        return (
                        <button
                            key={status}
                            onClick={() => handleStatusChange(status)}
                            disabled={ticket.status === status}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
                            ticket.status === status 
                                ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                            }`}
                        >
                            {status === TicketStatus.CLOSED && <Archive size={12} className="inline mr-1 mb-0.5" />}
                            {STATUS_LABELS[status]}
                            {ticket.status === status && <CheckCircle2 size={12} className="inline ml-1 mb-0.5" />}
                        </button>
                    )})}
                </div>
            </div>
        )}
      </div>

      {/* 2. TIMELINE & CHAT */}
      <div className="bg-white rounded-2xl shadow-lg shadow-slate-200/50 border border-slate-100 flex flex-col min-h-[500px]">
        <div className="bg-slate-50/80 px-8 py-4 border-b border-slate-100 backdrop-blur-sm sticky top-0 z-10 rounded-t-2xl">
            <h3 className="font-bold text-slate-800 flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                Timeline de Atendimento
            </h3>
        </div>
        
        <div className="p-8 space-y-8 flex-1 bg-white overflow-y-auto max-h-[600px] custom-scrollbar">
            {ticket.comments.length === 0 && (
                <div className="flex flex-col items-center justify-center py-12 text-slate-400">
                    <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                        <CheckCircle2 size={32} />
                    </div>
                    <p>Nenhuma interação registrada.</p>
                </div>
            )}
            
            {ticket.comments.map((comment) => {
            const isSystem = comment.type === 'SYSTEM_LOG';
            const commentUser = users.find(u => u.id === comment.userId);
            const isMe = comment.userId === user.id;

            if (isSystem) {
                return (
                <div key={comment.id} className="flex justify-center w-full">
                    <span className="text-[11px] font-bold text-slate-400 bg-slate-100 px-4 py-1.5 rounded-full uppercase tracking-wider border border-slate-200">
                    {comment.content} • {format(new Date(comment.createdAt), 'HH:mm')}
                    </span>
                </div>
                );
            }

            return (
                <div key={comment.id} className={`flex w-full ${isMe ? 'justify-end' : 'justify-start'}`}>
                <div className={`flex max-w-[85%] ${isMe ? 'flex-row-reverse' : 'flex-row'} items-end gap-3`}>
                    <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden shrink-0 shadow-sm border-2 border-white">
                        <img src={commentUser?.avatarUrl || `https://ui-avatars.com/api/?name=${commentUser?.name}`} alt="Avatar" className="w-full h-full object-cover" />
                    </div>
                    
                    <div className={`relative px-6 py-4 shadow-sm ${
                        isMe 
                        ? 'bg-blue-600 text-white rounded-2xl rounded-br-sm' 
                        : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-2xl rounded-bl-sm'
                    }`}>
                        <div className={`flex items-baseline justify-between gap-4 mb-1 text-xs ${isMe ? 'text-blue-100' : 'text-slate-500'}`}>
                            <span className="font-bold">{commentUser?.name}</span>
                            <span>{format(new Date(comment.createdAt), 'dd MMM HH:mm')}</span>
                        </div>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{comment.content}</p>
                    </div>
                </div>
                </div>
            );
            })}
            <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-6 bg-white border-t border-slate-100 rounded-b-2xl">
            <form onSubmit={handleSubmitComment} className="flex gap-4 items-end">
                <button type="button" className="p-3 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all">
                <Paperclip size={22} />
                </button>
                <div className="flex-1 relative">
                <textarea
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Escreva uma resposta..."
                    rows={1}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 focus:outline-none transition-all resize-none shadow-inner"
                    style={{ minHeight: '52px' }}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSubmitComment(e);
                        }
                    }}
                />
                </div>
                <button 
                type="submit"
                disabled={!commentText.trim()}
                className="bg-blue-600 text-white p-3.5 rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:hover:bg-blue-600 transition-all shadow-lg shadow-blue-500/30 hover:scale-105 active:scale-95"
                >
                <Send size={20} className={commentText.trim() ? "translate-x-0.5" : ""} />
                </button>
            </form>
            <p className="text-xs text-slate-400 mt-2 ml-14 text-center sm:text-left">Pressione Enter para enviar</p>
        </div>
      </div>
    </div>
  );
};

export default TicketDetail;

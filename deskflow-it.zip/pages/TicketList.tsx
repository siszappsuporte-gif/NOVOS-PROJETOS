
import React, { useState, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import { Plus, Search, ChevronRight, Inbox, SlidersHorizontal, ArrowUpDown, ArrowUp, ArrowDown, User as UserIcon, MessageSquare } from 'lucide-react';
import { TicketCategory, TicketPriority, TicketStatus, Role, Ticket } from '../types';
import { StatusBadge, PriorityBadge } from '../components/StatusBadge';
import { format } from 'date-fns';

// Move outside component to avoid recreation
const PRIORITY_WEIGHTS = {
  [TicketPriority.LOW]: 1,
  [TicketPriority.MEDIUM]: 2,
  [TicketPriority.HIGH]: 3,
  [TicketPriority.CRITICAL]: 4,
};

const STATUS_LABELS: Record<string, string> = {
  [TicketStatus.OPEN]: 'Aberto',
  [TicketStatus.IN_PROGRESS]: 'Em Andamento',
  [TicketStatus.WAITING_USER]: 'Aguardando Usuário',
  [TicketStatus.RESOLVED]: 'Resolvido',
  [TicketStatus.CLOSED]: 'Encerrado',
};

const PRIORITY_LABELS: Record<string, string> = {
  [TicketPriority.LOW]: 'Baixa',
  [TicketPriority.MEDIUM]: 'Média',
  [TicketPriority.HIGH]: 'Alta',
  [TicketPriority.CRITICAL]: 'Crítica',
};

const TicketList: React.FC = () => {
  const { tickets, createTicket, users } = useData();
  const { user } = useAuth();
  
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Tooltip State
  const [hoveredTicket, setHoveredTicket] = useState<{ ticket: Ticket; top: number; left: number } | null>(null);

  // Sorting State
  const [sortConfig, setSortConfig] = useState<{ key: keyof Ticket; direction: 'asc' | 'desc' } | null>({
    key: 'updatedAt',
    direction: 'desc'
  });

  // New Ticket Form State
  const [newTicket, setNewTicket] = useState({
    title: '',
    description: '',
    category: TicketCategory.HARDWARE,
    priority: TicketPriority.LOW
  });

  const handleSort = (key: keyof Ticket) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const processedTickets = useMemo(() => {
    // 1. Filter
    let result = tickets.filter(ticket => {
      // Permission Filter
      if (user?.role === Role.EMPLOYEE && ticket.requesterId !== user.id) return false;

      // UI Filters
      const matchesStatus = filterStatus === 'ALL' || ticket.status === filterStatus;
      if (!matchesStatus) return false;

      // Search Optimization: Check only if term exists
      if (searchTerm) {
          const lowerTerm = searchTerm.toLowerCase();
          return ticket.title.toLowerCase().includes(lowerTerm) || 
                 ticket.id.toLowerCase().includes(lowerTerm);
      }
      return true;
    });

    // 2. Sort
    if (sortConfig) {
      result = [...result].sort((a, b) => {
        const { key, direction } = sortConfig;
        const modifier = direction === 'asc' ? 1 : -1;

        // Custom Logic for Priority
        if (key === 'priority') {
          const weightA = PRIORITY_WEIGHTS[a.priority] || 0;
          const weightB = PRIORITY_WEIGHTS[b.priority] || 0;
          return (weightA - weightB) * modifier;
        }

        // Custom Logic for Dates - Optimized: String Comparison for ISO dates is faster than new Date()
        if (key === 'updatedAt' || key === 'createdAt') {
            if (a[key] > b[key]) return 1 * modifier;
            if (a[key] < b[key]) return -1 * modifier;
            return 0;
        }

        // Default String/Enum sorting
        const valA = String(a[key]).toLowerCase();
        const valB = String(b[key]).toLowerCase();
        
        return valA.localeCompare(valB) * modifier;
      });
    }

    return result;
  }, [tickets, user, filterStatus, searchTerm, sortConfig]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    createTicket({
      ...newTicket,
      requesterId: user.id,
      status: TicketStatus.OPEN
    });
    setShowCreateModal(false);
    setNewTicket({
      title: '',
      description: '',
      category: TicketCategory.HARDWARE,
      priority: TicketPriority.LOW
    });
  };

  // Helper to render sort icon
  const SortIcon = ({ columnKey }: { columnKey: keyof Ticket }) => {
    if (sortConfig?.key !== columnKey) return <ArrowUpDown size={14} className="text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity" />;
    return sortConfig.direction === 'asc' 
      ? <ArrowUp size={14} className="text-blue-600" />
      : <ArrowDown size={14} className="text-blue-600" />;
  };

  const SortableHeader = ({ label, columnKey }: { label: string, columnKey: keyof Ticket }) => (
    <th 
      className="px-6 py-5 cursor-pointer hover:bg-slate-100 transition-colors group select-none"
      onClick={() => handleSort(columnKey)}
    >
      <div className="flex items-center gap-2">
        {label}
        <SortIcon columnKey={columnKey} />
      </div>
    </th>
  );

  // Tooltip Logic Handlers
  const handleMouseEnterRow = (e: React.MouseEvent<HTMLTableRowElement>, ticket: Ticket) => {
    const rect = e.currentTarget.getBoundingClientRect();
    // Position slightly below the row cursor, centered or offset
    setHoveredTicket({
      ticket,
      top: rect.bottom + window.scrollY - 10,
      left: e.clientX + 20
    });
  };

  const handleMouseLeaveRow = () => {
    setHoveredTicket(null);
  };

  // Tooltip Content Helper
  const getTicketTooltipContent = (ticket: Ticket) => {
    const assignee = users.find(u => u.id === ticket.assigneeId);
    const lastComment = ticket.comments.length > 0 ? ticket.comments[ticket.comments.length - 1] : null;
    const lastCommentUser = lastComment ? users.find(u => u.id === lastComment.userId) : null;
    
    return (
      <div className="space-y-3">
        {/* Assignee Section */}
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
           <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center shrink-0 overflow-hidden">
              {assignee ? <img src={assignee.avatarUrl} className="w-full h-full object-cover" /> : <UserIcon size={14} className="text-slate-400" />}
           </div>
           <div>
              <p className="text-[10px] text-slate-400 uppercase font-bold">Responsável</p>
              <p className="text-xs font-bold text-slate-700">{assignee ? assignee.name : 'Não atribuído'}</p>
           </div>
        </div>
        
        {/* Interaction Section */}
        <div>
           <p className="text-[10px] text-slate-400 uppercase font-bold mb-1 flex items-center gap-1">
             <MessageSquare size={10} /> Última Interação
           </p>
           {lastComment ? (
             <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                <p className="text-[10px] text-slate-500 mb-1 flex justify-between">
                   <span className="font-semibold text-slate-600">{lastCommentUser?.name || 'Sistema'}</span>
                   <span>{format(new Date(lastComment.createdAt), 'dd/MM HH:mm')}</span>
                </p>
                <p className="text-xs text-slate-600 line-clamp-2 italic">"{lastComment.content}"</p>
             </div>
           ) : (
             <p className="text-xs text-slate-400 italic pl-1">Nenhuma interação registrada.</p>
           )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-[fadeIn_0.5s_ease-out] relative">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
           <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Meus Chamados</h1>
           <p className="text-slate-500 font-medium mt-1">Gerencie suas solicitações e acompanhe o progresso.</p>
        </div>
        <button 
          onClick={() => setShowCreateModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-xl flex items-center shadow-lg shadow-blue-500/30 transition-all hover:scale-105 active:scale-95 font-medium"
        >
          <Plus size={20} className="mr-2" />
          Novo Chamado
        </button>
      </div>

      {/* Filters Toolbar */}
      <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-3 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="Pesquisar por ID ou assunto..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/50 bg-slate-50 focus:bg-white transition-all"
          />
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <div className="relative w-full md:w-48">
            <SlidersHorizontal className="absolute left-3 top-3 text-slate-500" size={16} />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full pl-10 pr-8 py-2.5 border border-slate-200 rounded-xl appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-medium text-slate-600 cursor-pointer hover:border-blue-300 transition-colors"
            >
              <option value="ALL">Todos os Status</option>
              {Object.values(TicketStatus).map(s => (
                <option key={s} value={s}>{STATUS_LABELS[s]}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-lg shadow-slate-200/50 border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 text-xs font-bold uppercase tracking-wider border-b border-slate-100">
                <SortableHeader label="ID" columnKey="id" />
                <SortableHeader label="Assunto" columnKey="title" />
                <SortableHeader label="Categoria" columnKey="category" />
                <SortableHeader label="Status" columnKey="status" />
                <SortableHeader label="Prioridade" columnKey="priority" />
                <SortableHeader label="Atualizado em" columnKey="updatedAt" />
                <th className="px-6 py-5"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {processedTickets.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-16 text-center text-slate-500">
                    <div className="flex flex-col items-center justify-center">
                        <Inbox size={48} className="text-slate-300 mb-3" />
                        <p className="text-lg font-medium text-slate-600">Nenhum chamado encontrado</p>
                        <p className="text-sm">Tente ajustar os filtros ou crie uma nova solicitação.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                processedTickets.map((ticket) => (
                  <tr 
                    key={ticket.id} 
                    className="hover:bg-blue-50/50 transition-colors group relative"
                    onMouseEnter={(e) => handleMouseEnterRow(e, ticket)}
                    onMouseLeave={handleMouseLeaveRow}
                  >
                    <td className="px-6 py-4">
                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-mono font-bold">{ticket.id}</span>
                    </td>
                    <td className="px-6 py-4">
                      <Link to={`/tickets/${ticket.id}`} className="font-semibold text-slate-800 hover:text-blue-600 transition-colors block">
                        {ticket.title}
                      </Link>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-50 text-slate-700 border border-slate-200">
                            {ticket.category}
                        </span>
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={ticket.status} />
                    </td>
                    <td className="px-6 py-4">
                      <PriorityBadge priority={ticket.priority} />
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500 font-medium">
                      {format(new Date(ticket.updatedAt), 'dd MMM, HH:mm')}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Link 
                        to={`/tickets/${ticket.id}`} 
                        className="text-slate-300 hover:text-blue-600 transition-colors inline-block p-2 rounded-full hover:bg-blue-50"
                      >
                        <ChevronRight size={20} />
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Floating Tooltip Portal */}
      {hoveredTicket && (
        <div 
            className="fixed z-50 bg-white rounded-xl shadow-2xl shadow-blue-900/10 border border-slate-200 p-4 w-72 animate-[fadeIn_0.2s_ease-out] pointer-events-none"
            style={{ 
                top: Math.min(hoveredTicket.top, window.innerHeight - 200), // Prevent going off-screen bottom
                left: Math.min(hoveredTicket.left, window.innerWidth - 300) // Prevent going off-screen right
            }}
        >
            {getTicketTooltipContent(hoveredTicket.ticket)}
            
            {/* Arrow */}
            <div className="absolute -top-1.5 left-4 w-3 h-3 bg-white border-t border-l border-slate-200 transform rotate-45"></div>
        </div>
      )}

      {/* Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-[scaleIn_0.2s_ease-out]">
            <div className="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="font-bold text-xl text-slate-800">Abrir Novo Chamado</h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-full p-1 transition">
                <Plus size={24} className="rotate-45" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="p-8 space-y-5">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Assunto</label>
                <input
                  required
                  type="text"
                  className="w-full border border-slate-300 rounded-xl px-4 py-3 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 focus:outline-none transition-all"
                  value={newTicket.title}
                  onChange={e => setNewTicket({...newTicket, title: e.target.value})}
                  placeholder="Ex: Impressora não responde"
                />
              </div>
              <div className="grid grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Categoria</label>
                  <div className="relative">
                    <select
                        className="w-full border border-slate-300 rounded-xl px-4 py-3 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 focus:outline-none appearance-none bg-white transition-all"
                        value={newTicket.category}
                        onChange={e => setNewTicket({...newTicket, category: e.target.value as TicketCategory})}
                    >
                        {Object.values(TicketCategory).map(c => (
                        <option key={c} value={c}>{c}</option>
                        ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-500">
                        <svg className="h-4 w-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/></svg>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Prioridade</label>
                  <div className="relative">
                    <select
                        className="w-full border border-slate-300 rounded-xl px-4 py-3 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 focus:outline-none appearance-none bg-white transition-all"
                        value={newTicket.priority}
                        onChange={e => setNewTicket({...newTicket, priority: e.target.value as TicketPriority})}
                    >
                        {Object.values(TicketPriority).map(p => (
                        <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                        ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-500">
                         <svg className="h-4 w-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/></svg>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Descrição</label>
                <textarea
                  required
                  rows={4}
                  className="w-full border border-slate-300 rounded-xl px-4 py-3 focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 focus:outline-none transition-all resize-none"
                  value={newTicket.description}
                  onChange={e => setNewTicket({...newTicket, description: e.target.value})}
                  placeholder="Por favor, descreva o problema detalhadamente..."
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Anexo (Opcional)</label>
                 <div className="border border-dashed border-slate-300 rounded-xl p-4 bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer">
                     <input type="file" className="block w-full text-sm text-slate-500
                        file:mr-4 file:py-2 file:px-4
                        file:rounded-full file:border-0
                        file:text-sm file:font-semibold
                        file:bg-blue-100 file:text-blue-700
                        hover:file:bg-blue-200
                        cursor-pointer
                    "/>
                 </div>
              </div>
              <div className="pt-4 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-6 py-3 text-slate-600 hover:bg-slate-100 rounded-xl font-medium transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-500/30 transition-all hover:-translate-y-0.5"
                >
                  Criar Chamado
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TicketList;

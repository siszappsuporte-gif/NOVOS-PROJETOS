
export enum Role {
  EMPLOYEE = 'EMPLOYEE',
  TECHNICIAN = 'TECHNICIAN',
  ADMIN = 'ADMIN'
}

export enum TicketStatus {
  OPEN = 'OPEN',
  IN_PROGRESS = 'IN_PROGRESS',
  WAITING_USER = 'WAITING_USER',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED'
}

export enum TicketPriority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export enum TicketCategory {
  HARDWARE = 'HARDWARE',
  SOFTWARE = 'SOFTWARE',
  NETWORK = 'NETWORK',
  ACCESS = 'ACCESS',
  OTHER = 'OTHER'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  department: string;
  avatarUrl?: string;
  isOnline: boolean;
}

export interface Comment {
  id: string;
  ticketId: string;
  userId: string;
  content: string;
  createdAt: string; // ISO Date string
  type: 'COMMENT' | 'SYSTEM_LOG';
}

export interface Ticket {
  id: string;
  title: string;
  description: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  requesterId: string;
  assigneeId?: string;
  createdAt: string;
  updatedAt: string;
  comments: Comment[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId?: string; // If null, it's a channel/group message (simplified here to direct)
  content: string;
  timestamp: string;
  read: boolean;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: TicketCategory;
  authorId: string;
  likes: number;
  views: number;
  createdAt: string;
}

// Novos Tipos para Ativos
export enum AssetType {
  LAPTOP = 'LAPTOP',
  DESKTOP = 'DESKTOP',
  MONITOR = 'MONITOR',
  SOFTWARE = 'SOFTWARE',
  PERIPHERAL = 'PERIPHERAL'
}

export enum AssetStatus {
  AVAILABLE = 'AVAILABLE',
  IN_USE = 'IN_USE',
  MAINTENANCE = 'MAINTENANCE',
  RETIRED = 'RETIRED'
}

export interface Asset {
  id: string;
  name: string;
  type: AssetType;
  serialNumber: string;
  status: AssetStatus;
  assignedToUserId?: string;
  purchaseDate: string;
  model: string;
}

// Novos Tipos para Status de Serviços
export enum ServiceHealthStatus {
  OPERATIONAL = 'OPERATIONAL',
  DEGRADED = 'DEGRADED',
  OUTAGE = 'OUTAGE',
  MAINTENANCE = 'MAINTENANCE'
}

export interface ServiceHealth {
  id: string;
  name: string;
  status: ServiceHealthStatus;
  uptime: number; // Porcentagem
  lastIncident?: string;
  description: string;
}
